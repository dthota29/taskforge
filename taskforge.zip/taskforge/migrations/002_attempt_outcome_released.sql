-- A graceful worker shutdown hands in-flight jobs back to the queue ("released"). The attempt is not
-- the job's fault, so it is not counted against max_attempts, and it needs its own audit outcome.
ALTER TABLE job_attempts DROP CONSTRAINT job_attempts_outcome_valid;
ALTER TABLE job_attempts ADD CONSTRAINT job_attempts_outcome_valid CHECK (
  outcome IS NULL OR outcome IN ('succeeded','failed','lease_expired','released')
);
