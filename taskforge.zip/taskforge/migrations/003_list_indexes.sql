-- Keyset pagination for GET /v1/jobs (ORDER BY created_at DESC, id DESC), unfiltered and by status.
-- These add write cost to the hot table, so only the two access paths the API exposes are indexed.
CREATE INDEX jobs_created_idx ON jobs (created_at DESC, id DESC);
CREATE INDEX jobs_status_created_idx ON jobs (status, created_at DESC, id DESC);
