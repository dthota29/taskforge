-- TaskForge initial schema.
-- Conventions: timestamptz everywhere (UTC), text + CHECK instead of enums (cheap to evolve),
-- invariants enforced in the database so no code path can create an impossible state.

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- API keys (only the SHA-256 hash is stored; the raw key is shown once at creation)
-- ---------------------------------------------------------------------------
CREATE TABLE api_keys (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text        NOT NULL,
  key_hash     text        NOT NULL UNIQUE,
  scopes       text[]      NOT NULL DEFAULT ARRAY['jobs:read','jobs:write']::text[],
  created_at   timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz,
  revoked_at   timestamptz,
  CONSTRAINT api_keys_name_not_blank CHECK (length(btrim(name)) > 0)
);

-- ---------------------------------------------------------------------------
-- Cron schedules: a schedule materialises into ordinary jobs at each fire time
-- ---------------------------------------------------------------------------
CREATE TABLE schedules (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text        NOT NULL UNIQUE,
  cron_expr     text        NOT NULL,
  timezone      text        NOT NULL DEFAULT 'UTC',
  queue         text        NOT NULL DEFAULT 'default',
  type          text        NOT NULL,
  payload       jsonb       NOT NULL DEFAULT '{}'::jsonb,
  priority      smallint    NOT NULL DEFAULT 0,
  max_attempts  integer     NOT NULL DEFAULT 5,
  enabled       boolean     NOT NULL DEFAULT true,
  next_fire_at  timestamptz NOT NULL,
  last_fired_at timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT schedules_priority_range CHECK (priority BETWEEN -100 AND 100),
  CONSTRAINT schedules_max_attempts_positive CHECK (max_attempts BETWEEN 1 AND 100)
);

-- The scheduler only ever asks "which enabled schedules are due?"
CREATE INDEX schedules_due_idx ON schedules (next_fire_at) WHERE enabled;

CREATE TRIGGER schedules_set_updated_at
  BEFORE UPDATE ON schedules FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Jobs
--   queued    -> waiting for run_at (also the state a failed job returns to between retries)
--   running   -> leased by exactly one worker (locked_by + lease_expires_at + fence)
--   succeeded -> terminal
--   dead      -> terminal, retries exhausted: this is the dead-letter queue
--   cancelled -> terminal
-- ---------------------------------------------------------------------------
CREATE TABLE jobs (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  queue            text        NOT NULL DEFAULT 'default',
  type             text        NOT NULL,
  payload          jsonb       NOT NULL DEFAULT '{}'::jsonb,
  status           text        NOT NULL DEFAULT 'queued',
  priority         smallint    NOT NULL DEFAULT 0,          -- higher runs first
  run_at           timestamptz NOT NULL DEFAULT now(),
  attempts         integer     NOT NULL DEFAULT 0,
  max_attempts     integer     NOT NULL DEFAULT 5,
  -- lease / fencing
  locked_by        text,
  lease_expires_at timestamptz,
  fence            bigint      NOT NULL DEFAULT 0,          -- incremented on every claim
  -- deduplication
  idempotency_key  text,
  schedule_id      uuid REFERENCES schedules(id) ON DELETE SET NULL,
  scheduled_for    timestamptz,                             -- the cron fire time this job represents
  -- outcome
  last_error       text,
  result           jsonb,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  started_at       timestamptz,
  finished_at      timestamptz,

  CONSTRAINT jobs_status_valid CHECK (status IN ('queued','running','succeeded','dead','cancelled')),
  CONSTRAINT jobs_priority_range CHECK (priority BETWEEN -100 AND 100),
  CONSTRAINT jobs_max_attempts_positive CHECK (max_attempts BETWEEN 1 AND 100),
  CONSTRAINT jobs_attempts_nonnegative CHECK (attempts >= 0),
  CONSTRAINT jobs_type_not_blank CHECK (length(btrim(type)) > 0),
  CONSTRAINT jobs_idempotency_key_not_blank CHECK (idempotency_key IS NULL OR length(btrim(idempotency_key)) > 0),
  -- a running job must be leased; a non-running job must not hold a lease
  CONSTRAINT jobs_lease_consistent CHECK (
    (status = 'running'  AND locked_by IS NOT NULL AND lease_expires_at IS NOT NULL)
    OR
    (status <> 'running' AND locked_by IS NULL     AND lease_expires_at IS NULL)
  ),
  -- terminal states carry a finish time
  CONSTRAINT jobs_finished_consistent CHECK (
    (status IN ('succeeded','dead','cancelled')) = (finished_at IS NOT NULL)
  )
);

-- Hot path: claim the next runnable job. Partial index keeps it tiny regardless of history size.
-- Column order matches the ORDER BY of the claim query.
CREATE INDEX jobs_claim_idx ON jobs (queue, priority DESC, run_at ASC, id ASC) WHERE status = 'queued';

-- Reaper: find leases that have expired.
CREATE INDEX jobs_lease_expiry_idx ON jobs (lease_expires_at) WHERE status = 'running';

-- DLQ listing and retention pruning.
CREATE INDEX jobs_dead_idx ON jobs (finished_at DESC) WHERE status = 'dead';
CREATE INDEX jobs_finished_idx ON jobs (finished_at) WHERE status IN ('succeeded','cancelled');

-- Idempotency: one logical job per (queue, key). Enforced by the database, not by app code.
CREATE UNIQUE INDEX jobs_idempotency_uidx ON jobs (queue, idempotency_key) WHERE idempotency_key IS NOT NULL;

-- Cron safety net: a schedule can materialise at most one job per fire time,
-- even if two scheduler instances race.
CREATE UNIQUE INDEX jobs_schedule_fire_uidx ON jobs (schedule_id, scheduled_for) WHERE schedule_id IS NOT NULL;

CREATE TRIGGER jobs_set_updated_at
  BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Attempt history: one row per execution attempt (debugging, audit, metrics)
-- ---------------------------------------------------------------------------
CREATE TABLE job_attempts (
  id          bigserial PRIMARY KEY,
  job_id      uuid        NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  attempt     integer     NOT NULL,
  fence       bigint      NOT NULL,
  worker_id   text        NOT NULL,
  started_at  timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  outcome     text,                                          -- succeeded | failed | lease_expired | rejected_stale
  error       text,
  CONSTRAINT job_attempts_outcome_valid CHECK (
    outcome IS NULL OR outcome IN ('succeeded','failed','lease_expired','rejected_stale')
  ),
  CONSTRAINT job_attempts_unique UNIQUE (job_id, attempt, fence)
);

CREATE INDEX job_attempts_job_idx ON job_attempts (job_id, attempt);
