import pg from 'pg';

/** Create the database named in `url` if it does not exist yet (dev/test/benchmark tooling only). */
export async function ensureDatabase(url: string): Promise<void> {
  const target = new URL(url);
  const name = decodeURIComponent(target.pathname.slice(1));
  if (!/^[A-Za-z0-9_]+$/.test(name)) throw new Error(`refusing unusual database name "${name}"`);
  target.pathname = '/postgres';
  const client = new pg.Client({ connectionString: target.toString() });
  await client.connect();
  try {
    const { rowCount } = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [name]);
    if (!rowCount) await client.query(`CREATE DATABASE "${name}"`);
  } catch (err) {
    if ((err as { code?: string }).code !== '42P04') throw err; // already created by a concurrent run
  } finally {
    await client.end();
  }
}

/** Destructive helpers must only ever point at a throwaway database. */
export function assertDisposableDatabase(url: string, marker: 'test' | 'bench'): void {
  const name = decodeURIComponent(new URL(url).pathname.slice(1));
  if (!name.includes(marker)) {
    throw new Error(`refusing to run against database "${name}": its name must contain "${marker}"`);
  }
}
