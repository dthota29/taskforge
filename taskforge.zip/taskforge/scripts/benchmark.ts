/**
 * TaskForge benchmark: N jobs drained by W real worker processes against one Postgres.
 *
 *   npm run bench                  # 20,000 jobs, 16 workers
 *   npm run bench:chaos            # same, but SIGKILL 3 workers at ~30% to prove crash recovery
 *   npm run bench -- --jobs 5000 --workers 8 --concurrency 5
 *
 * The run FAILS (exit code 1) if any correctness invariant is violated, so a green run is evidence,
 * not just a number. Correctness is checked against evidence the scheduler cannot fake: the handler
 * records every execution in its own table (bench_executions), independent of the scheduler's
 * job and attempt bookkeeping.
 */
import { fork } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { enqueue } from '../src/core/jobs.js';
import { migrate } from '../src/db/migrate.js';
import { createPool } from '../src/db/pool.js';
import { assertDisposableDatabase, ensureDatabase } from './lib/db.js';

const args = process.argv.slice(2);
const flag = (name: string) => args.includes(`--${name}`);
const opt = (name: string, def: number) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? Number(args[i + 1]) : def;
};

const JOBS = opt('jobs', 20_000);
const WORKERS = opt('workers', 16);
const CONCURRENCY = opt('concurrency', 10);
const CHAOS = flag('chaos');
const KILL = opt('kill', 3);
const LEASE = opt('lease', CHAOS ? 5 : 30);
const SEED_CONCURRENCY = 32;

const url = process.env.BENCH_DATABASE_URL ?? 'postgres://taskforge:taskforge@localhost:5433/taskforge_bench';
assertDisposableDatabase(url, 'bench');

const here = path.dirname(fileURLToPath(import.meta.url));
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const fmt = (n: number, d = 1) => n.toLocaleString('en-US', { maximumFractionDigits: d });

interface Check {
  name: string;
  expected: string;
  actual: string;
  ok: boolean;
}
const checks: Check[] = [];
const check = (name: string, expected: unknown, actual: unknown, ok = expected === actual) =>
  checks.push({ name, expected: String(expected), actual: String(actual), ok });

async function main() {
  await ensureDatabase(url);
  const pool = createPool(url, 10);
  await migrate(pool);
  await pool.query(`CREATE TABLE IF NOT EXISTS bench_executions (
    id bigserial PRIMARY KEY, job_id uuid NOT NULL, worker_id text NOT NULL, attempt int NOT NULL, at timestamptz NOT NULL DEFAULT now())`);
  await pool.query('TRUNCATE bench_executions, job_attempts, jobs, schedules RESTART IDENTITY CASCADE');

  console.log(`\nTaskForge benchmark: ${fmt(JOBS, 0)} jobs, ${WORKERS} workers x ${CONCURRENCY} concurrency${CHAOS ? `, chaos (kill ${KILL})` : ''}`);

  // ---- 1. enqueue through the real enqueue() path ----
  let next = 0;
  const seedStart = performance.now();
  await Promise.all(
    Array.from({ length: SEED_CONCURRENCY }, async () => {
      while (next < JOBS) {
        const i = next++;
        await enqueue(pool, { type: 'bench.noop', payload: { i }, priority: i % 10 === 0 ? 10 : 0 });
      }
    }),
  );
  const seedSeconds = (performance.now() - seedStart) / 1000;
  console.log(`enqueued ${fmt(JOBS, 0)} jobs in ${fmt(seedSeconds)}s (${fmt(JOBS / seedSeconds, 0)} jobs/s, ${SEED_CONCURRENCY} concurrent submitters)`);

  // ---- 2. prove the claim query uses the partial index on a loaded table ----
  await pool.query('ANALYZE jobs');
  const planClient = await pool.connect();
  let plan: string[] = [];
  try {
    await planClient.query('BEGIN');
    const res = await planClient.query(
      `EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
       SELECT id FROM jobs WHERE status = 'queued' AND queue = 'default' AND run_at <= now()
       ORDER BY priority DESC, run_at ASC, id ASC LIMIT 10 FOR UPDATE SKIP LOCKED`,
    );
    plan = res.rows.map((r) => r['QUERY PLAN'] as string);
    await planClient.query('ROLLBACK');
  } finally {
    planClient.release();
  }
  const usesIndex = plan.some((l) => l.includes('jobs_claim_idx'));
  check('claim query uses jobs_claim_idx', true, usesIndex);

  // ---- 3. start the workers and release them together ----
  const children: ChildProcess[] = [];
  const ready: Promise<void>[] = [];
  for (let i = 0; i < WORKERS; i++) {
    const child = fork(path.join(here, 'bench-worker.ts'), [], {
      execArgv: ['--import', 'tsx'],
      env: {
        ...process.env,
        BENCH_DATABASE_URL: url,
        WORKER_ID: `bench-${String(i).padStart(2, '0')}`,
        CONCURRENCY: String(CONCURRENCY),
        LEASE_SECONDS: String(LEASE),
      },
    });
    children.push(child);
    ready.push(
      new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error(`worker ${i} did not start`)), 60_000);
        child.once('message', () => {
          clearTimeout(t);
          resolve();
        });
        child.once('error', reject);
      }),
    );
  }
  await Promise.all(ready);
  console.log(`${WORKERS} worker processes ready; releasing them against a ${fmt(JOBS, 0)}-job backlog`);

  const runStart = performance.now();
  for (const c of children) c.send({ type: 'go' });

  // ---- 4. wait for the drain (optionally killing workers part-way) ----
  const killed: string[] = [];
  let lastPrint = 0;
  let killedAt = 0;
  for (;;) {
    const { rows } = await pool.query<{ done: number }>("SELECT count(*)::int AS done FROM jobs WHERE status = 'succeeded'");
    const done = rows[0]!.done;
    const elapsed = (performance.now() - runStart) / 1000;
    if (performance.now() - lastPrint > 2_000) {
      lastPrint = performance.now();
      console.log(`  ${fmt(elapsed)}s  ${fmt(done, 0)}/${fmt(JOBS, 0)} done  (${fmt(done / elapsed, 0)} jobs/s)`);
    }
    if (CHAOS && killed.length === 0 && done >= JOBS * 0.3) {
      killedAt = elapsed;
      for (const c of children.slice(0, KILL)) {
        c.kill('SIGKILL');
        killed.push(`bench-${String(children.indexOf(c)).padStart(2, '0')}`);
      }
      console.log(`  >>> SIGKILLed ${killed.join(', ')} at ${fmt(elapsed)}s with their jobs still leased`);
    }
    if (done >= JOBS) break;
    if (elapsed > 600) throw new Error('benchmark timed out after 10 minutes');
    await sleep(250);
  }
  const wallSeconds = (performance.now() - runStart) / 1000;

  for (const c of children) if (!c.killed && c.connected) c.send({ type: 'stop' });
  await Promise.race([
    Promise.all(children.filter((c) => c.exitCode === null && !c.killed).map((c) => new Promise((r) => c.once('exit', r)))),
    sleep(20_000),
  ]);
  for (const c of children) if (c.exitCode === null && !c.killed) c.kill('SIGKILL');

  // ---- 5. verify, using evidence independent of the scheduler's own bookkeeping ----
  const one = async <T>(sql: string) => (await pool.query(sql)).rows[0] as T;

  const totals = await one<{ jobs: number; succeeded: number }>(
    "SELECT count(*)::int AS jobs, count(*) FILTER (WHERE status='succeeded')::int AS succeeded FROM jobs",
  );
  check('jobs submitted', JOBS, totals.jobs);
  check('jobs succeeded', JOBS, totals.succeeded);

  const exec = await one<{ executions: number; distinct_jobs: number }>(
    'SELECT count(*)::int AS executions, count(DISTINCT job_id)::int AS distinct_jobs FROM bench_executions',
  );
  check('every job executed at least once', JOBS, exec.distinct_jobs);

  const attempts = await one<{ total: number; succeeded: number; expired: number; open: number; multi_success: number; bad_fence: number }>(
    `SELECT count(*)::int AS total,
            count(*) FILTER (WHERE outcome = 'succeeded')::int AS succeeded,
            count(*) FILTER (WHERE outcome = 'lease_expired')::int AS expired,
            count(*) FILTER (WHERE outcome IS NULL)::int AS open,
            (SELECT count(*)::int FROM (SELECT job_id FROM job_attempts WHERE outcome = 'succeeded' GROUP BY job_id HAVING count(*) > 1) x) AS multi_success,
            (SELECT count(*)::int FROM (SELECT job_id FROM job_attempts GROUP BY job_id HAVING min(fence) <> 1 OR max(fence) <> count(*)) y) AS bad_fence
     FROM job_attempts`,
  );
  check('jobs completed by exactly one attempt', 0, attempts.multi_success);
  check('fencing tokens contiguous per job (1..k)', 0, attempts.bad_fence);
  check('no claim left open', 0, attempts.open);
  check('attempt rows that succeeded', JOBS, attempts.succeeded);

  let duplicateClaims: number;
  let reExecutions: number;
  if (CHAOS) {
    reExecutions = exec.executions - exec.distinct_jobs;
    check('crashed-worker claims recovered by the reaper', true, attempts.expired > 0);
    duplicateClaims = 0; // re-claims after lease expiry are recoveries, not duplicates; invariants above prove it
  } else {
    // A claim is "duplicate" if a job was claimed more than once, or ran more than once.
    const dup = await one<{ n: number }>('SELECT count(*)::int AS n FROM (SELECT job_id FROM job_attempts GROUP BY job_id HAVING count(*) > 1) d');
    duplicateClaims = dup.n;
    reExecutions = exec.executions - exec.distinct_jobs;
    check('DUPLICATE CLAIMS (job claimed more than once)', 0, duplicateClaims);
    check('total handler executions', JOBS, exec.executions);
    check('no lease expired in a healthy run', 0, attempts.expired);
  }

  const lat = await one<{ q: number[] }>(
    `SELECT percentile_cont(ARRAY[0.5, 0.95, 0.99]) WITHIN GROUP (ORDER BY extract(epoch FROM finished_at - started_at) * 1000) AS q FROM jobs`,
  );
  const dist = await one<{ min: number; max: number; avg: number; workers: number }>(
    `SELECT min(n)::int AS min, max(n)::int AS max, avg(n)::float8 AS avg, count(*)::int AS workers
     FROM (SELECT worker_id, count(*) AS n FROM job_attempts GROUP BY worker_id) t`,
  );
  const pg = await one<{ v: string }>('SHOW server_version');
  await pool.end();

  // ---- 6. report ----
  const allOk = checks.every((c) => c.ok);
  const lines: string[] = [];
  const out = (s = '') => lines.push(s);
  out(`# TaskForge benchmark results${CHAOS ? ' (chaos)' : ''}`);
  out();
  out(`Result: **${allOk ? 'PASS' : 'FAIL'}**. Generated ${new Date().toISOString()} by \`npm run ${CHAOS ? 'bench:chaos' : 'bench'}\`.`);
  out();
  out('## Setup');
  out(`- ${fmt(JOBS, 0)} jobs, ${WORKERS} worker processes x ${CONCURRENCY} concurrent handlers (${WORKERS * CONCURRENCY} in flight), one PostgreSQL ${(pg as unknown as { server_version: string }).server_version}`);
  out(`- Host: ${os.cpus().length} logical CPUs (${os.cpus()[0]?.model.trim()}), ${fmt(os.totalmem() / 2 ** 30, 0)} GiB RAM, ${os.platform()}, Node ${process.version}. Database in Docker, same host, so results are a lower bound on a dedicated database.`);
  out(`- Workload: handler does one INSERT per job (a realistic minimum: real handlers do I/O). Lease ${LEASE}s.`);
  out(`- Every job is enqueued first, then all workers are released at once against the full backlog: the maximum-contention case for \`FOR UPDATE SKIP LOCKED\`.`);
  if (CHAOS) out(`- Chaos: ${killed.join(', ')} were SIGKILLed at ${fmt(killedAt)}s with jobs in flight.`);
  out();
  out('## Throughput and latency');
  out('| Metric | Value |');
  out('|---|---|');
  out(`| Enqueue (API path, ${SEED_CONCURRENCY} submitters) | ${fmt(JOBS / seedSeconds, 0)} jobs/s |`);
  out(`| Drain wall time | ${fmt(wallSeconds)} s |`);
  out(`| Processing throughput | **${fmt(JOBS / wallSeconds, 0)} jobs/s** |`);
  out(`| Claim to finish, p50 / p95 / p99 | ${fmt(lat.q[0]!)} / ${fmt(lat.q[1]!)} / ${fmt(lat.q[2]!)} ms |`);
  out(`| Jobs per worker (min / avg / max) | ${dist.min} / ${fmt(dist.avg, 0)} / ${dist.max} across ${dist.workers} workers |`);
  out();
  out('## Correctness checks');
  out('| Check | Expected | Actual | |');
  out('|---|---|---|---|');
  for (const c of checks) out(`| ${c.name} | ${c.expected} | ${c.actual} | ${c.ok ? 'ok' : '**FAILED**'} |`);
  if (CHAOS) {
    out();
    out(`Crash recovery: ${attempts.expired} claims held by dead workers were reclaimed after lease expiry, and ${reExecutions} jobs ran again (at-least-once delivery). Each job was still completed by exactly one attempt.`);
  }
  out();
  out('## Claim query plan on the loaded table');
  out('```');
  for (const l of plan) out(l);
  out('```');

  const report = lines.join('\n') + '\n';
  const outDir = path.resolve(here, '../docs');
  await mkdir(outDir, { recursive: true });
  await writeFile(path.join(outDir, CHAOS ? 'benchmark-chaos.md' : 'benchmark.md'), report);

  console.log('\n' + report);
  if (!allOk) {
    console.error('BENCHMARK FAILED: correctness invariant violated');
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
