/**
 * One benchmark worker process. Runs the production Worker class and reaper loop, with a handler
 * that records every execution in bench_executions so the parent can prove how often each job ran.
 * Spawned (never run by hand) by scripts/benchmark.ts, which gates the start with a "go" message
 * so that all workers begin pulling from the backlog at the same moment.
 */
import { reapExpiredLeases } from '../src/core/reaper.js';
import { runLoop } from '../src/core/loop.js';
import { createPool } from '../src/db/pool.js';
import { createLogger } from '../src/logger.js';
import { HandlerRegistry } from '../src/worker/registry.js';
import { Worker } from '../src/worker/worker.js';

const url = process.env.BENCH_DATABASE_URL!;
const workerId = process.env.WORKER_ID!;
const lease = Number(process.env.LEASE_SECONDS ?? 30);

const pool = createPool(url, 5);
const logger = createLogger('silent');

const registry = new HandlerRegistry().register('bench.noop', async (_payload, ctx) => {
  await pool.query('INSERT INTO bench_executions (job_id, worker_id, attempt) VALUES ($1, $2, $3)', [
    ctx.jobId,
    workerId,
    ctx.attempt,
  ]);
});

const worker = new Worker(
  pool,
  registry,
  {
    workerId,
    queues: ['default'],
    concurrency: Number(process.env.CONCURRENCY ?? 10),
    leaseSeconds: lease,
    heartbeatSeconds: Math.max(1, lease / 3),
    pollIntervalMs: 20,
    drainTimeoutMs: 10_000,
  },
  logger,
);
const reaper = runLoop('reaper', 2_000, async () => void (await reapExpiredLeases(pool)), logger);

process.on('message', async (msg: { type: string }) => {
  if (msg.type === 'go') worker.start();
  if (msg.type === 'stop') {
    await reaper.stop();
    await worker.stop();
    await pool.end();
    process.exit(0);
  }
});
process.send?.({ type: 'ready' });
