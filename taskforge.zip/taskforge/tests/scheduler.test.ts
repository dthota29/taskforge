import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import {
  createSchedule,
  enqueue,
  InvalidScheduleError,
  pruneFinishedJobs,
  ScheduleConflictError,
  setScheduleEnabled,
} from '../src/core/index.js';
import type { Pool } from '../src/db/pool.js';
import { createLogger } from '../src/logger.js';
import { fireDueSchedules } from '../src/scheduler/cron.js';
import { LeaderElection } from '../src/scheduler/leader.js';
import { resetDb, setupDb } from './helpers.js';

let pool: Pool;
beforeAll(async () => {
  pool = await setupDb();
});
afterAll(async () => {
  await pool.end();
});
beforeEach(async () => {
  await resetDb(pool);
});

const makeDue = (id: string, minutesAgo: number) =>
  pool.query("UPDATE schedules SET next_fire_at = now() - make_interval(mins => $2) WHERE id = $1", [id, minutesAgo]);
const jobCount = async () => (await pool.query('SELECT count(*)::int AS n FROM jobs')).rows[0].n as number;

describe('schedule validation', () => {
  it('rejects bad cron expressions, 6-field cron and unknown timezones', async () => {
    await expect(createSchedule(pool, { name: 'a', cron: 'not a cron', type: 't' })).rejects.toBeInstanceOf(InvalidScheduleError);
    await expect(createSchedule(pool, { name: 'a', cron: '* * * * * *', type: 't' })).rejects.toBeInstanceOf(InvalidScheduleError);
    await expect(createSchedule(pool, { name: 'a', cron: '61 * * * *', type: 't' })).rejects.toBeInstanceOf(InvalidScheduleError);
    await expect(createSchedule(pool, { name: 'a', cron: '* * * * *', timezone: 'Mars/Base', type: 't' })).rejects.toBeInstanceOf(InvalidScheduleError);
  });

  it('rejects a duplicate name', async () => {
    await createSchedule(pool, { name: 'dup', cron: '* * * * *', type: 't' });
    await expect(createSchedule(pool, { name: 'dup', cron: '* * * * *', type: 't' })).rejects.toBeInstanceOf(ScheduleConflictError);
  });

  it('computes the first fire time in the future, in the schedule timezone', async () => {
    const s = await createSchedule(pool, { name: 'ny', cron: '0 9 * * *', timezone: 'America/New_York', type: 't' });
    expect(s.nextFireAt.getTime()).toBeGreaterThan(Date.now());
    const hour = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: 'numeric', hourCycle: 'h23' }).format(s.nextFireAt);
    expect(Number(hour)).toBe(9);
  });
});

describe('fireDueSchedules', () => {
  it('creates a job for the due fire time and advances next_fire_at', async () => {
    const s = await createSchedule(pool, { name: 'every5', cron: '*/5 * * * *', type: 'report', payload: { x: 1 }, priority: 3 });
    await makeDue(s.id, 1);
    const before = (await pool.query('SELECT next_fire_at FROM schedules WHERE id=$1', [s.id])).rows[0].next_fire_at as Date;

    expect(await fireDueSchedules(pool)).toBe(1);

    const { rows } = await pool.query('SELECT * FROM jobs');
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ type: 'report', payload: { x: 1 }, priority: 3, schedule_id: s.id });
    expect(rows[0].scheduled_for.getTime()).toBe(before.getTime());
    const after = (await pool.query('SELECT next_fire_at, last_fired_at FROM schedules WHERE id=$1', [s.id])).rows[0];
    expect(after.next_fire_at.getTime()).toBeGreaterThan(Date.now());
    expect(after.last_fired_at).not.toBeNull();

    expect(await fireDueSchedules(pool)).toBe(0); // not due again
  });

  it('fires once, not once per missed tick, after downtime', async () => {
    const s = await createSchedule(pool, { name: 'hourly', cron: '0 * * * *', type: 't' });
    await makeDue(s.id, 5 * 60); // missed ~5 hours of fires
    expect(await fireDueSchedules(pool)).toBe(1);
    expect(await jobCount()).toBe(1);
    expect(await fireDueSchedules(pool)).toBe(0);
  });

  it('ignores disabled schedules, and re-enabling does not replay a backlog', async () => {
    const s = await createSchedule(pool, { name: 'paused', cron: '* * * * *', type: 't' });
    await setScheduleEnabled(pool, s.id, false);
    await makeDue(s.id, 30);
    expect(await fireDueSchedules(pool)).toBe(0);

    const enabled = await setScheduleEnabled(pool, s.id, true);
    expect(enabled!.nextFireAt.getTime()).toBeGreaterThan(Date.now());
    expect(await fireDueSchedules(pool)).toBe(0);
  });

  it('creates exactly one job when several schedulers fire concurrently', async () => {
    const s = await createSchedule(pool, { name: 'race', cron: '*/5 * * * *', type: 't' });
    await makeDue(s.id, 1);
    await Promise.all(Array.from({ length: 6 }, () => fireDueSchedules(pool)));
    expect(await jobCount()).toBe(1);
  });

  it('the unique index alone blocks a double fire (safety net if locking ever failed)', async () => {
    const s = await createSchedule(pool, { name: 'net', cron: '*/5 * * * *', type: 't' });
    const at = new Date(Date.now() - 60_000);
    const a = await enqueue(pool, { type: 't', scheduleId: s.id, scheduledFor: at });
    const b = await enqueue(pool, { type: 't', scheduleId: s.id, scheduledFor: at });
    expect(a.created).toBe(true);
    expect(b.created).toBe(false);
    expect(b.job.id).toBe(a.job.id);
    expect(await jobCount()).toBe(1);
  });
});

describe('leader election', () => {
  const logger = createLogger('silent');
  const LOCK = 999_001;

  it('allows only one leader, and hands over when it steps down', async () => {
    const a = new LeaderElection(pool, LOCK, logger);
    const b = new LeaderElection(pool, LOCK, logger);
    expect(await a.tryAcquire()).toBe(true);
    expect(await b.tryAcquire()).toBe(false);
    expect(await a.tryAcquire()).toBe(true); // re-confirming is cheap and stable

    await a.release();
    expect(await b.tryAcquire()).toBe(true);
    await b.release();
  });

  it('fails over when the leader connection dies', async () => {
    const a = new LeaderElection(pool, LOCK, logger);
    const b = new LeaderElection(pool, LOCK, logger);
    expect(await a.tryAcquire()).toBe(true);

    // Kill the leader's backend, as a network partition or pod crash would.
    await pool.query(
      `SELECT pg_terminate_backend(pid) FROM pg_locks
       WHERE locktype = 'advisory' AND objid = $1 AND granted`,
      [LOCK],
    );
    await new Promise((r) => setTimeout(r, 100));

    expect(await b.tryAcquire()).toBe(true);
    expect(await a.tryAcquire()).toBe(false); // old leader notices and stays down
    await b.release();
  });
});

describe('retention', () => {
  it('deletes old finished jobs, keeps recent ones, and keeps dead jobs longer', async () => {
    await pool.query(`
      INSERT INTO jobs (type, status, finished_at) VALUES
        ('old-ok',   'succeeded', now() - interval '10 days'),
        ('new-ok',   'succeeded', now() - interval '1 day'),
        ('old-dead', 'dead',      now() - interval '10 days'),
        ('ancient-dead', 'dead',  now() - interval '40 days'),
        ('queued',   'queued',    NULL)`);
    const deleted = await pruneFinishedJobs(pool, { finishedDays: 7, deadDays: 30 });
    expect(deleted).toBe(2);
    const { rows } = await pool.query('SELECT type FROM jobs ORDER BY type');
    expect(rows.map((r) => r.type)).toEqual(['new-ok', 'old-dead', 'queued']);
  });
});
