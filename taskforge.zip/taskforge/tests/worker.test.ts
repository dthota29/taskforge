import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { enqueue, getJob } from '../src/core/index.js';
import type { Pool } from '../src/db/pool.js';
import { createLogger } from '../src/logger.js';
import { HandlerRegistry, NonRetryableError } from '../src/worker/registry.js';
import type { WorkerOptions } from '../src/worker/worker.js';
import { Worker } from '../src/worker/worker.js';
import { resetDb, setupDb, sleep, waitFor } from './helpers.js';

const logger = createLogger('silent');
const tinyBackoff = { baseMs: 1, factor: 1, maxMs: 1 };

let pool: Pool;
let workers: Worker[] = [];

beforeAll(async () => {
  pool = await setupDb();
});
afterAll(async () => {
  await pool.end();
});
beforeEach(async () => {
  await resetDb(pool);
});
afterEach(async () => {
  await Promise.all(workers.map((w) => w.stop()));
  workers = [];
});

function startWorker(registry: HandlerRegistry, overrides: Partial<WorkerOptions> = {}): Worker {
  const worker = new Worker(
    pool,
    registry,
    {
      workerId: `test-${workers.length}`,
      queues: ['default'],
      concurrency: 4,
      leaseSeconds: 2,
      heartbeatSeconds: 0.5,
      pollIntervalMs: 20,
      drainTimeoutMs: 2_000,
      abortGraceMs: 300,
      backoff: tinyBackoff,
      ...overrides,
    },
    logger,
  );
  workers.push(worker);
  worker.start();
  return worker;
}

const statusOf = async (id: string) => (await getJob(pool, id))?.status;
const waitStatus = (id: string, status: string, timeout = 8_000) =>
  waitFor(async () => (await statusOf(id)) === status, timeout, `job ${id} to be ${status}`);

describe('worker execution', () => {
  it('runs a handler and stores its result', async () => {
    const registry = new HandlerRegistry().register('echo', async (p) => ({ got: p }));
    startWorker(registry);
    const { job } = await enqueue(pool, { type: 'echo', payload: { n: 7 } });
    await waitStatus(job.id, 'succeeded');
    expect((await getJob(pool, job.id))?.result).toEqual({ got: { n: 7 } });
  });

  it('retries a failing job with backoff until it succeeds', async () => {
    const registry = new HandlerRegistry().register('flaky', async (_p, ctx) => {
      if (ctx.attempt < 3) throw new Error(`fail #${ctx.attempt}`);
      return 'ok';
    });
    startWorker(registry);
    const { job } = await enqueue(pool, { type: 'flaky', maxAttempts: 5 });
    await waitStatus(job.id, 'succeeded');
    expect((await getJob(pool, job.id))?.attempts).toBe(3);
    const { rows } = await pool.query('SELECT outcome FROM job_attempts WHERE job_id=$1 ORDER BY attempt', [job.id]);
    expect(rows.map((r) => r.outcome)).toEqual(['failed', 'failed', 'succeeded']);
  });

  it('dead-letters after max attempts', async () => {
    const registry = new HandlerRegistry().register('bad', async () => {
      throw new Error('always');
    });
    startWorker(registry);
    const { job } = await enqueue(pool, { type: 'bad', maxAttempts: 2 });
    await waitStatus(job.id, 'dead');
    expect(await getJob(pool, job.id)).toMatchObject({ attempts: 2, lastError: 'Error: always' });
  });

  it('dead-letters immediately on NonRetryableError', async () => {
    const registry = new HandlerRegistry().register('bad-input', async () => {
      throw new NonRetryableError('nope');
    });
    startWorker(registry);
    const { job } = await enqueue(pool, { type: 'bad-input', maxAttempts: 5 });
    await waitStatus(job.id, 'dead');
    expect((await getJob(pool, job.id))?.attempts).toBe(1);
  });

  it('treats an unknown job type as a retryable failure', async () => {
    startWorker(new HandlerRegistry());
    const { job } = await enqueue(pool, { type: 'mystery', maxAttempts: 2 });
    await waitStatus(job.id, 'dead');
    expect((await getJob(pool, job.id))?.lastError).toContain('no handler registered');
  });

  it('never exceeds the concurrency limit', async () => {
    let active = 0;
    let peak = 0;
    const registry = new HandlerRegistry().register('slow', async () => {
      active++;
      peak = Math.max(peak, active);
      await sleep(80);
      active--;
    });
    startWorker(registry, { concurrency: 2 });
    const ids = await Promise.all(Array.from({ length: 6 }, () => enqueue(pool, { type: 'slow' }).then((r) => r.job.id)));
    for (const id of ids) await waitStatus(id, 'succeeded');
    expect(peak).toBe(2);
  });

  it('fails a handler that exceeds its timeout, and aborts its signal', async () => {
    let aborted = false;
    const registry = new HandlerRegistry().register('hang', {
      timeoutMs: 150,
      handle: (_p, ctx) =>
        new Promise((_res, rej) => {
          ctx.signal.addEventListener('abort', () => {
            aborted = true;
            rej(new Error('aborted'));
          });
        }),
    });
    startWorker(registry);
    const { job } = await enqueue(pool, { type: 'hang', maxAttempts: 1 });
    await waitStatus(job.id, 'dead');
    expect(aborted).toBe(true);
    expect((await getJob(pool, job.id))?.lastError).toContain('timed out');
  });
});

describe('leases', () => {
  it('heartbeats keep a long job alive past its lease', async () => {
    const registry = new HandlerRegistry().register('long', async () => {
      await sleep(3_200); // longer than 1.5 leases
      return 'done';
    });
    startWorker(registry, { leaseSeconds: 1.5, heartbeatSeconds: 0.4 });
    const { job } = await enqueue(pool, { type: 'long' });
    await waitStatus(job.id, 'succeeded', 10_000);
    const after = await getJob(pool, job.id);
    expect(after?.attempts).toBe(1); // never reaped or re-run
    const { rows } = await pool.query('SELECT outcome FROM job_attempts WHERE job_id=$1', [job.id]);
    expect(rows.map((r) => r.outcome)).toEqual(['succeeded']);
  });

  it('aborts the handler and discards its result when the lease is lost', async () => {
    let sawAbort = false;
    let finished = false;
    const registry = new HandlerRegistry().register('victim', async (_p, ctx) => {
      await new Promise<void>((resolve) => ctx.signal.addEventListener('abort', () => resolve()));
      sawAbort = true;
      finished = true; // a misbehaving handler that ignores the abort and returns "successfully"
      return 'late result';
    });
    startWorker(registry, { heartbeatSeconds: 0.2 });
    const { job } = await enqueue(pool, { type: 'victim' });
    await waitFor(async () => (await statusOf(job.id)) === 'running', 5_000, 'job to start');

    // Simulate the job being reclaimed by another worker: the fence moves on.
    await pool.query("UPDATE jobs SET fence = fence + 1, locked_by = 'other-worker' WHERE id = $1", [job.id]);

    await waitFor(async () => sawAbort, 5_000, 'handler to be aborted');
    await sleep(200);
    expect(finished).toBe(true);
    // The late result must not have been written over the new owner's job.
    const after = await getJob(pool, job.id);
    expect(after).toMatchObject({ status: 'running', lockedBy: 'other-worker', result: null });
  });
});

describe('graceful shutdown', () => {
  it('lets in-flight jobs finish and claims nothing new', async () => {
    const registry = new HandlerRegistry().register('work', async () => {
      await sleep(400);
      return 'done';
    });
    const worker = startWorker(registry);
    const { job } = await enqueue(pool, { type: 'work' });
    await waitFor(async () => (await statusOf(job.id)) === 'running', 5_000, 'job to start');

    const stopped = worker.stop();
    const later = await enqueue(pool, { type: 'work' }); // arrives after shutdown began
    await stopped;

    expect(await statusOf(job.id)).toBe('succeeded');
    await sleep(150);
    expect(await statusOf(later.job.id)).toBe('queued');
  });

  it('releases a job back to the queue, without burning an attempt, when the drain times out', async () => {
    const registry = new HandlerRegistry().register('stubborn', (_p, ctx) =>
      new Promise((_res, rej) => ctx.signal.addEventListener('abort', () => rej(new Error('aborted')))),
    );
    const worker = startWorker(registry, { drainTimeoutMs: 200 });
    const { job } = await enqueue(pool, { type: 'stubborn' });
    await waitFor(async () => (await statusOf(job.id)) === 'running', 5_000, 'job to start');

    await worker.stop();

    const after = await getJob(pool, job.id);
    expect(after).toMatchObject({ status: 'queued', attempts: 0, lockedBy: null });
    const { rows } = await pool.query('SELECT outcome FROM job_attempts WHERE job_id=$1', [job.id]);
    expect(rows.map((r) => r.outcome)).toEqual(['released']);
  });
});
