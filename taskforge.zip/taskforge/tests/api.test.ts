import type { FastifyInstance } from 'fastify';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { buildApp } from '../src/api/app.js';
import { claim, createApiKey, enqueue, getJob } from '../src/core/index.js';
import type { Scope } from '../src/core/index.js';
import type { Pool } from '../src/db/pool.js';
import { createLogger } from '../src/logger.js';
import { createMetrics, registerQueueGauges } from '../src/metrics.js';
import type { Metrics } from '../src/metrics.js';
import { resetDb, setupDb } from './helpers.js';

let pool: Pool;
let app: FastifyInstance;
let metrics: Metrics;
let state: { shuttingDown: boolean };

const keys: Record<string, string> = {};

async function makeKey(name: string, scopes: Scope[]) {
  keys[name] = (await createApiKey(pool, { name, scopes })).key;
  return keys[name]!;
}

async function startApp(limits = { ipPerMinute: 100_000, keyPerMinute: 100_000 }) {
  metrics = createMetrics();
  state = { shuttingDown: false };
  app = await buildApp({ pool, logger: createLogger('silent'), metrics, limits, trustProxy: false, state });
  await app.ready();
}

const call = (method: 'GET' | 'POST' | 'PATCH' | 'DELETE', url: string, key?: string, payload?: unknown, headers: Record<string, string> = {}) =>
  app.inject({
    method,
    url,
    payload: payload as object | undefined,
    headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), ...headers },
  });

beforeAll(async () => {
  pool = await setupDb();
});
afterAll(async () => {
  await pool.end();
});
beforeEach(async () => {
  await resetDb(pool);
  await makeKey('admin', ['admin']);
  await makeKey('rw', ['jobs:read', 'jobs:write']);
  await makeKey('ro', ['jobs:read']);
  await startApp();
});
afterEach(async () => {
  await app.close();
});

describe('authentication and authorization', () => {
  it('rejects missing, malformed and unknown keys with 401 and a challenge header', async () => {
    for (const authorization of [undefined, 'Bearer', 'Basic abc', 'Bearer short', `Bearer tf_${'x'.repeat(43)}`]) {
      const res = await app.inject({ method: 'GET', url: '/v1/stats', headers: authorization ? { authorization } : {} });
      expect(res.statusCode, String(authorization)).toBe(401);
      expect(res.headers['www-authenticate']).toBe('Bearer');
      expect(res.json().error.code).toBe('unauthorized');
    }
    expect(metrics.authFailures).toBeDefined();
  });

  it('enforces scopes: read-only cannot write; job keys cannot touch schedules or keys', async () => {
    expect((await call('POST', '/v1/jobs', keys.ro, { type: 't' })).statusCode).toBe(403);
    expect((await call('GET', '/v1/jobs', keys.ro)).statusCode).toBe(200);
    expect((await call('GET', '/v1/schedules', keys.rw)).statusCode).toBe(403);
    expect((await call('GET', '/v1/api-keys', keys.rw)).statusCode).toBe(403);
    const denied = await call('POST', '/v1/jobs', keys.ro, { type: 't' });
    expect(denied.json().error.code).toBe('forbidden');
  });

  it('lets an admin key do everything', async () => {
    expect((await call('POST', '/v1/jobs', keys.admin, { type: 't' })).statusCode).toBe(201);
    expect((await call('GET', '/v1/schedules', keys.admin)).statusCode).toBe(200);
    expect((await call('GET', '/v1/api-keys', keys.admin)).statusCode).toBe(200);
  });

  it('serves health, readiness and the OpenAPI document without a key', async () => {
    for (const url of ['/healthz', '/readyz', '/openapi.json']) {
      expect((await app.inject({ method: 'GET', url })).statusCode, url).toBe(200);
    }
  });

  it('readiness fails while shutting down but liveness stays up', async () => {
    state.shuttingDown = true;
    expect((await app.inject({ method: 'GET', url: '/readyz' })).statusCode).toBe(503);
    expect((await app.inject({ method: 'GET', url: '/healthz' })).statusCode).toBe(200);
  });
});

describe('errors', () => {
  it('uses one error shape with a request id, and echoes a supplied x-request-id', async () => {
    const res = await call('GET', '/v1/jobs/00000000-0000-4000-8000-000000000000', keys.rw, undefined, {
      'x-request-id': 'trace-abc-12345',
    });
    expect(res.statusCode).toBe(404);
    expect(res.json()).toEqual({ error: { code: 'not_found', message: 'job not found', requestId: 'trace-abc-12345' } });
    expect(res.headers['x-request-id']).toBe('trace-abc-12345');
  });

  it('generates a request id when none (or an unsafe one) is supplied', async () => {
    const res = await call('GET', '/v1/stats', keys.rw, undefined, { 'x-request-id': 'bad id with spaces!' });
    expect(res.headers['x-request-id']).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('returns 404 in the standard shape for unknown routes', async () => {
    const res = await app.inject({ method: 'GET', url: '/nope' });
    expect(res.statusCode).toBe(404);
    expect(res.json().error.code).toBe('not_found');
  });

  it('rejects malformed JSON with 400 and oversized bodies with 413', async () => {
    const bad = await app.inject({
      method: 'POST',
      url: '/v1/jobs',
      payload: '{not json',
      headers: { authorization: `Bearer ${keys.rw}`, 'content-type': 'application/json' },
    });
    expect(bad.statusCode).toBe(400);
    expect(bad.json().error.code).toBe('bad_request');

    const big = await call('POST', '/v1/jobs', keys.rw, { type: 't', payload: 'x'.repeat(300 * 1024) });
    expect(big.statusCode).toBe(413);
    expect(big.json().error.code).toBe('payload_too_large');
  });

  it('sets no-store and nosniff headers', async () => {
    const res = await call('GET', '/v1/stats', keys.rw);
    expect(res.headers['cache-control']).toBe('no-store');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});

describe('submitting jobs', () => {
  it('creates a job with defaults and makes it readable', async () => {
    const res = await call('POST', '/v1/jobs', keys.rw, { type: 'email', payload: { to: 'a@b.c' } });
    expect(res.statusCode).toBe(201);
    const job = res.json();
    expect(job).toMatchObject({ type: 'email', queue: 'default', status: 'queued', priority: 0, maxAttempts: 5, payload: { to: 'a@b.c' } });
    expect(job.fence).toBeUndefined(); // internal detail, not exposed

    const got = await call('GET', `/v1/jobs/${job.id}`, keys.ro);
    expect(got.json().id).toBe(job.id);
  });

  it('honours delayMs and runAt', async () => {
    const delayed = (await call('POST', '/v1/jobs', keys.rw, { type: 't', delayMs: 60_000 })).json();
    expect(new Date(delayed.runAt).getTime()).toBeGreaterThan(Date.now() + 50_000);
    const at = new Date(Date.now() + 3_600_000).toISOString();
    const scheduled = (await call('POST', '/v1/jobs', keys.rw, { type: 't', runAt: at })).json();
    expect(scheduled.runAt).toBe(at);
  });

  it.each([
    [{}, 'type'],
    [{ type: 'bad type!' }, 'type'],
    [{ type: 't', priority: 500 }, 'priority'],
    [{ type: 't', maxAttempts: 0 }, 'maxAttempts'],
    [{ type: 't', queue: 'a/b' }, 'queue'],
    [{ type: 't', runAt: 'tomorrow' }, 'runAt'],
    [{ type: 't', delayMs: 1, runAt: new Date().toISOString() }, 'runAt'],
    [{ type: 't', unknownField: 1 }, ''],
  ])('rejects invalid body %j', async (body, field) => {
    const res = await call('POST', '/v1/jobs', keys.rw, body);
    expect(res.statusCode).toBe(400);
    const err = res.json().error;
    expect(err.code).toBe('validation_error');
    if (field) expect(err.details.map((d: { path: string }) => d.path)).toContain(field);
  });

  it('is idempotent via body key and via Idempotency-Key header', async () => {
    const a = await call('POST', '/v1/jobs', keys.rw, { type: 'pay', idempotencyKey: 'k1' });
    const b = await call('POST', '/v1/jobs', keys.rw, { type: 'pay', idempotencyKey: 'k1' });
    expect([a.statusCode, b.statusCode]).toEqual([201, 200]);
    expect(b.headers['idempotent-replay']).toBe('true');
    expect(b.json().id).toBe(a.json().id);

    const c = await call('POST', '/v1/jobs', keys.rw, { type: 'pay' }, { 'idempotency-key': 'k2' });
    const d = await call('POST', '/v1/jobs', keys.rw, { type: 'pay' }, { 'idempotency-key': 'k2' });
    expect(d.json().id).toBe(c.json().id);
    expect(c.json().idempotencyKey).toBe('k2');
  });

  it('creates one job when identical submits race', async () => {
    const results = await Promise.all(
      Array.from({ length: 12 }, () => call('POST', '/v1/jobs', keys.rw, { type: 'pay', idempotencyKey: 'race' })),
    );
    expect(new Set(results.map((r) => r.json().id)).size).toBe(1);
    expect(results.filter((r) => r.statusCode === 201)).toHaveLength(1);
  });
});

describe('reading and managing jobs', () => {
  it('validates ids: malformed is 400, unknown is 404', async () => {
    expect((await call('GET', '/v1/jobs/not-a-uuid', keys.rw)).statusCode).toBe(400);
    expect((await call('GET', '/v1/jobs/00000000-0000-4000-8000-000000000000', keys.rw)).statusCode).toBe(404);
    expect((await call('POST', '/v1/jobs/00000000-0000-4000-8000-000000000000/cancel', keys.rw)).statusCode).toBe(404);
  });

  it('paginates newest-first with a cursor and walks every job exactly once', async () => {
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) ids.push((await call('POST', '/v1/jobs', keys.rw, { type: 't', payload: { i } })).json().id);

    const seen: string[] = [];
    let cursor: string | null = null;
    let pages = 0;
    do {
      const url: string = `/v1/jobs?limit=2${cursor ? `&cursor=${cursor}` : ''}`;
      const body = (await call('GET', url, keys.ro)).json();
      seen.push(...body.jobs.map((j: { id: string }) => j.id));
      cursor = body.nextCursor;
      pages++;
    } while (cursor);

    expect(pages).toBe(3);
    expect(seen).toEqual([...ids].reverse());
  });

  it('rejects a bad cursor and supports filters', async () => {
    expect((await call('GET', '/v1/jobs?cursor=garbage', keys.ro)).json().error.code).toBe('invalid_cursor');
    await call('POST', '/v1/jobs', keys.rw, { type: 'a', queue: 'q1' });
    await call('POST', '/v1/jobs', keys.rw, { type: 'b', queue: 'q2' });
    expect((await call('GET', '/v1/jobs?queue=q1', keys.ro)).json().jobs).toHaveLength(1);
    expect((await call('GET', '/v1/jobs?type=b', keys.ro)).json().jobs[0].queue).toBe('q2');
    expect((await call('GET', '/v1/jobs?status=dead', keys.ro)).json().jobs).toHaveLength(0);
    expect((await call('GET', '/v1/jobs?limit=1000', keys.ro)).statusCode).toBe(400);
  });

  it('cancels a queued job once, then conflicts', async () => {
    const { id } = (await call('POST', '/v1/jobs', keys.rw, { type: 't' })).json();
    const first = await call('POST', `/v1/jobs/${id}/cancel`, keys.rw);
    expect(first.statusCode).toBe(200);
    expect(first.json().status).toBe('cancelled');
    expect((await call('POST', `/v1/jobs/${id}/cancel`, keys.rw)).statusCode).toBe(409);
  });

  it('lists the dead-letter queue and replays a dead job once', async () => {
    const { job } = await enqueue(pool, { type: 'doomed', maxAttempts: 1 });
    await pool.query("UPDATE jobs SET status='dead', attempts=1, finished_at=now(), last_error='boom' WHERE id=$1", [job.id]);

    const dlq = (await call('GET', '/v1/dead-letter-queue', keys.ro)).json();
    expect(dlq.jobs.map((j: { id: string }) => j.id)).toEqual([job.id]);
    expect(dlq.jobs[0].lastError).toBe('boom');

    const replayed = await call('POST', `/v1/jobs/${job.id}/replay`, keys.rw);
    expect(replayed.statusCode).toBe(200);
    expect(replayed.json()).toMatchObject({ status: 'queued', attempts: 0 });
    expect((await call('POST', `/v1/jobs/${job.id}/replay`, keys.rw)).statusCode).toBe(409);
    expect((await call('GET', '/v1/dead-letter-queue', keys.ro)).json().jobs).toHaveLength(0);
  });

  it('exposes the attempt history', async () => {
    const { job } = await enqueue(pool, { type: 't' });
    await claim(pool, { workerId: 'w-1', leaseSeconds: 30 });
    const res = (await call('GET', `/v1/jobs/${job.id}/attempts`, keys.ro)).json();
    expect(res.attempts).toHaveLength(1);
    expect(res.attempts[0]).toMatchObject({ attempt: 1, workerId: 'w-1', outcome: null });
  });

  it('reports queue statistics', async () => {
    await call('POST', '/v1/jobs', keys.rw, { type: 't', queue: 'emails' });
    await call('POST', '/v1/jobs', keys.rw, { type: 't', queue: 'emails' });
    await call('POST', '/v1/jobs', keys.rw, { type: 't', queue: 'emails', delayMs: 3_600_000 });
    const stats = (await call('GET', '/v1/stats', keys.ro)).json();
    expect(stats.queues).toEqual([
      expect.objectContaining({ queue: 'emails', queued: 3, ready: 2, running: 0 }),
    ]);
    expect(stats.dead).toBe(0);
  });
});

describe('schedules', () => {
  it('creates, reads, disables and deletes a schedule', async () => {
    const created = await call('POST', '/v1/schedules', keys.admin, {
      name: 'nightly', cron: '0 2 * * *', timezone: 'America/New_York', type: 'report',
    });
    expect(created.statusCode).toBe(201);
    const s = created.json();
    expect(s).toMatchObject({ name: 'nightly', cron: '0 2 * * *', enabled: true, timezone: 'America/New_York' });
    expect(new Date(s.nextFireAt).getTime()).toBeGreaterThan(Date.now());

    expect((await call('GET', `/v1/schedules/${s.id}`, keys.admin)).json().name).toBe('nightly');
    expect((await call('PATCH', `/v1/schedules/${s.id}`, keys.admin, { enabled: false })).json().enabled).toBe(false);
    expect((await call('DELETE', `/v1/schedules/${s.id}`, keys.admin)).statusCode).toBe(204);
    expect((await call('GET', `/v1/schedules/${s.id}`, keys.admin)).statusCode).toBe(404);
    expect((await call('DELETE', `/v1/schedules/${s.id}`, keys.admin)).statusCode).toBe(404);
  });

  it('rejects an invalid cron, an unknown timezone and a duplicate name', async () => {
    const bad = await call('POST', '/v1/schedules', keys.admin, { name: 'a', cron: '* * * * * *', type: 't' });
    expect(bad.statusCode).toBe(400);
    expect(bad.json().error.code).toBe('invalid_schedule');
    expect((await call('POST', '/v1/schedules', keys.admin, { name: 'a', cron: '* * * * *', timezone: 'Mars/Base', type: 't' })).statusCode).toBe(400);

    await call('POST', '/v1/schedules', keys.admin, { name: 'dup', cron: '* * * * *', type: 't' });
    const dup = await call('POST', '/v1/schedules', keys.admin, { name: 'dup', cron: '* * * * *', type: 't' });
    expect(dup.statusCode).toBe(409);
  });
});

describe('API keys', () => {
  it('shows the secret once, never lists it, and revocation takes effect immediately', async () => {
    const created = await call('POST', '/v1/api-keys', keys.admin, { name: 'ci', scopes: ['jobs:read', 'jobs:read'] });
    expect(created.statusCode).toBe(201);
    const { id, key, scopes } = created.json();
    expect(key).toMatch(/^tf_[A-Za-z0-9_-]{43}$/);
    expect(scopes).toEqual(['jobs:read']); // de-duplicated

    const listed = (await call('GET', '/v1/api-keys', keys.admin)).body;
    expect(listed).not.toContain(key);
    expect(listed).not.toContain('key_hash');

    expect((await call('GET', '/v1/jobs', key)).statusCode).toBe(200);
    expect((await call('DELETE', `/v1/api-keys/${id}`, keys.admin)).statusCode).toBe(204);
    expect((await call('GET', '/v1/jobs', key)).statusCode).toBe(401);
    expect((await call('DELETE', `/v1/api-keys/${id}`, keys.admin)).statusCode).toBe(404);
  });

  it('stores only a hash of the key', async () => {
    const { rows } = await pool.query('SELECT key_hash FROM api_keys WHERE name = $1', ['rw']);
    expect(rows[0].key_hash).toMatch(/^[0-9a-f]{64}$/);
    expect(rows[0].key_hash).not.toContain(keys.rw!.slice(3));
  });

  it('rejects unknown scopes', async () => {
    expect((await call('POST', '/v1/api-keys', keys.admin, { name: 'x', scopes: ['root'] })).statusCode).toBe(400);
  });
});

describe('rate limiting', () => {
  it('limits per API key and answers 429 with Retry-After', async () => {
    await app.close();
    await startApp({ ipPerMinute: 100_000, keyPerMinute: 3 });
    const statuses: number[] = [];
    let last;
    for (let i = 0; i < 5; i++) {
      last = await call('GET', '/v1/stats', keys.rw);
      statuses.push(last.statusCode);
    }
    expect(statuses).toEqual([200, 200, 200, 429, 429]);
    expect(Number(last!.headers['retry-after'])).toBeGreaterThanOrEqual(1);
    expect(last!.json().error.code).toBe('rate_limited');
    // a different key has its own budget
    expect((await call('GET', '/v1/stats', keys.admin)).statusCode).toBe(200);
  });

  it('limits by IP before authentication, protecting the key lookup, but never throttles probes', async () => {
    await app.close();
    await startApp({ ipPerMinute: 2, keyPerMinute: 100_000 });
    const codes = [];
    for (let i = 0; i < 4; i++) codes.push((await app.inject({ method: 'GET', url: '/v1/stats' })).statusCode);
    expect(codes).toEqual([401, 401, 429, 429]);
    for (let i = 0; i < 10; i++) expect((await app.inject({ method: 'GET', url: '/healthz' })).statusCode).toBe(200);
  });
});

describe('metrics', () => {
  it('labels HTTP series by route template, not by raw URL', async () => {
    const { id } = (await call('POST', '/v1/jobs', keys.rw, { type: 't' })).json();
    await call('GET', `/v1/jobs/${id}`, keys.rw);
    await app.inject({ method: 'GET', url: '/some/random/path/12345' });
    const text = await metrics.registry.metrics();
    expect(text).toContain('route="/v1/jobs/:id"');
    expect(text).toContain('route="unmatched"');
    expect(text).not.toContain(id);
    expect(text).not.toContain('12345');
    expect(text).toMatch(/taskforge_jobs_enqueued_total\{result="created"\} 1/);
  });

  it('reports queue depth and lag from the database at scrape time', async () => {
    registerQueueGauges(metrics, pool);
    await enqueue(pool, { type: 't', queue: 'emails', runAt: new Date(Date.now() - 5_000) });
    await enqueue(pool, { type: 't', queue: 'emails' });
    const text = await metrics.registry.metrics();
    expect(text).toContain('taskforge_queue_jobs{queue="emails",state="ready"} 2');
    const lag = /taskforge_queue_oldest_ready_age_seconds\{queue="emails"\} ([\d.]+)/.exec(text);
    expect(Number(lag?.[1])).toBeGreaterThanOrEqual(4);
    expect(text).toContain('taskforge_dead_jobs 0');
  });
});

describe('OpenAPI document', () => {
  it('describes every v1 route, with auth and request schemas, generated from the same source', async () => {
    const spec = (await app.inject({ method: 'GET', url: '/openapi.json' })).json();
    expect(spec.openapi).toBe('3.1.0');

    const documented = new Set<string>();
    for (const [path, ops] of Object.entries<Record<string, unknown>>(spec.paths)) {
      for (const method of Object.keys(ops)) documented.add(`${method.toUpperCase()} ${path}`);
    }
    expect(documented).toContain('POST /v1/jobs');
    expect(documented).toContain('GET /v1/jobs/{id}');
    expect(documented).toContain('POST /v1/jobs/{id}/replay');
    expect(documented).toContain('DELETE /v1/api-keys/{id}');
    expect(documented.size).toBe(16);

    const post = spec.paths['/v1/jobs'].post;
    expect(post.security).toEqual([{ bearerAuth: [] }]);
    expect(post.requestBody.content['application/json'].schema.properties.type).toBeDefined();
    expect(post.responses['429']).toBeDefined();
  });
});

describe('integration with the engine', () => {
  it('a job submitted over HTTP is claimable and completes through the core', async () => {
    const { id } = (await call('POST', '/v1/jobs', keys.rw, { type: 'echo', payload: { n: 1 } })).json();
    const [claimed] = await claim(pool, { workerId: 'w', leaseSeconds: 30 });
    expect(claimed?.id).toBe(id);
    expect((await getJob(pool, id))?.status).toBe('running');
    expect((await call('GET', `/v1/jobs/${id}`, keys.ro)).json().status).toBe('running');
  });
});
