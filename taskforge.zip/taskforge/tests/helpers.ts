import { migrate } from '../src/db/migrate.js';
import { createPool } from '../src/db/pool.js';
import type { Pool } from '../src/db/pool.js';
import { assertDisposableDatabase, ensureDatabase } from '../scripts/lib/db.js';

// Deliberately NOT DATABASE_URL: the suite TRUNCATEs tables, so it must never inherit a real database.
export const TEST_DATABASE_URL =
  process.env.TEST_DATABASE_URL ?? 'postgres://taskforge:taskforge@localhost:5433/taskforge_test';

export async function setupDb(max = 20): Promise<Pool> {
  assertDisposableDatabase(TEST_DATABASE_URL, 'test');
  await ensureDatabase(TEST_DATABASE_URL);
  const pool = createPool(TEST_DATABASE_URL, max);
  await migrate(pool);
  return pool;
}

export async function resetDb(pool: Pool): Promise<void> {
  await pool.query('TRUNCATE job_attempts, jobs, schedules, api_keys RESTART IDENTITY CASCADE');
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Poll until fn returns a truthy value; fail with a clear message on timeout. */
export async function waitFor<T>(fn: () => Promise<T | null | undefined | false>, timeoutMs = 10_000, label = 'condition'): Promise<T> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > deadline) throw new Error(`timed out waiting for ${label}`);
    await sleep(25);
  }
}

/** Force a running job's lease into the past, as if its worker died long ago. */
export async function expireLease(pool: Pool, jobId: string): Promise<void> {
  await pool.query("UPDATE jobs SET lease_expires_at = now() - interval '1 second' WHERE id = $1", [jobId]);
}
