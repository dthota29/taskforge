import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { RateLimiter } from '../src/api/ratelimit.js';
import { createLogger } from '../src/logger.js';
import { createMetrics, startMetricsServer } from '../src/metrics.js';

describe('RateLimiter (token bucket)', () => {
  it('allows a burst up to the limit, then refuses', () => {
    let t = 0;
    const rl = new RateLimiter(60, 5, 1000, () => t);
    const results = Array.from({ length: 7 }, () => rl.take('k').allowed);
    expect(results).toEqual([true, true, true, true, true, false, false]);
  });

  it('refills continuously at perMinute/60 per second', () => {
    let t = 0;
    const rl = new RateLimiter(60, 2, 1000, () => t); // 1 token per second
    rl.take('k');
    rl.take('k');
    expect(rl.take('k').allowed).toBe(false);
    t = 1_000;
    expect(rl.take('k').allowed).toBe(true);
    expect(rl.take('k').allowed).toBe(false);
    t = 10_000; // long idle: refill is capped at the burst size
    expect([rl.take('k').allowed, rl.take('k').allowed, rl.take('k').allowed]).toEqual([true, true, false]);
  });

  it('keeps keys independent and reports a sensible Retry-After', () => {
    let t = 0;
    const rl = new RateLimiter(6, 1, 1000, () => t); // 1 token per 10s
    expect(rl.take('a').allowed).toBe(true);
    const denied = rl.take('a');
    expect(denied.allowed).toBe(false);
    expect(denied.retryAfterSeconds).toBe(10);
    expect(rl.take('b').allowed).toBe(true);
  });

  it('bounds memory by evicting the oldest keys', () => {
    const rl = new RateLimiter(60, 1, 100);
    for (let i = 0; i < 1_000; i++) rl.take(`ip-${i}`);
    expect(rl.size).toBeLessThanOrEqual(100);
  });
});

describe('metrics server', () => {
  let server: http.Server;
  let base: string;
  beforeAll(async () => {
    server = startMetricsServer(createMetrics().registry, 0, createLogger('silent'));
    await new Promise((r) => server.once('listening', r));
    base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  });
  afterAll(() => new Promise<void>((r) => server.close(() => r())));

  it('serves Prometheus text on /metrics and liveness on /healthz', async () => {
    const m = await fetch(`${base}/metrics`);
    expect(m.status).toBe(200);
    expect(m.headers.get('content-type')).toContain('text/plain');
    expect(await m.text()).toContain('taskforge_http_request_duration_seconds');
    expect((await fetch(`${base}/healthz`)).status).toBe(200);
    expect((await fetch(`${base}/anything-else`)).status).toBe(404);
  });
});
