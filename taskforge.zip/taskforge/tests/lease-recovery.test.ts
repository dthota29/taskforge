import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { claim, complete, enqueue, fail, getJob, heartbeat, reapExpiredLeases } from '../src/core/index.js';
import type { Pool } from '../src/db/pool.js';
import { expireLease, resetDb, setupDb } from './helpers.js';

let pool: Pool;
beforeAll(async () => {
  pool = await setupDb();
});
afterAll(async () => {
  await pool.end();
});
beforeEach(async () => {
  await resetDb(pool);
});

async function claimOne(workerId: string) {
  const [job] = await claim(pool, { workerId, leaseSeconds: 30 });
  if (!job) throw new Error('expected a job to claim');
  return job;
}

describe('complete', () => {
  it('marks the job succeeded and closes the attempt', async () => {
    await enqueue(pool, { type: 'a' });
    const job = await claimOne('w1');
    expect(await complete(pool, job.id, job.fence, { ok: true })).toBe(true);
    const done = await getJob(pool, job.id);
    expect(done).toMatchObject({ status: 'succeeded', lockedBy: null, leaseExpiresAt: null, result: { ok: true } });
    expect(done?.finishedAt).not.toBeNull();
    const { rows } = await pool.query('SELECT outcome FROM job_attempts WHERE job_id = $1', [job.id]);
    expect(rows[0].outcome).toBe('succeeded');
  });

  it('rejects an ack with the wrong fence', async () => {
    await enqueue(pool, { type: 'a' });
    const job = await claimOne('w1');
    expect(await complete(pool, job.id, job.fence + 1)).toBe(false);
    expect((await getJob(pool, job.id))?.status).toBe('running');
  });
});

describe('heartbeat', () => {
  it('extends the lease for the owner and refuses a stale fence', async () => {
    await enqueue(pool, { type: 'a' });
    const job = await claimOne('w1');
    const before = (await getJob(pool, job.id))!.leaseExpiresAt!.getTime();
    expect(await heartbeat(pool, job.id, job.fence, 300)).toBe(true);
    const after = (await getJob(pool, job.id))!.leaseExpiresAt!.getTime();
    expect(after).toBeGreaterThan(before);
    expect(await heartbeat(pool, job.id, job.fence + 1, 300)).toBe(false);
  });
});

describe('fail and retry', () => {
  it('schedules a retry in the future with backoff and frees the lease', async () => {
    await enqueue(pool, { type: 'a', maxAttempts: 3 });
    const job = await claimOne('w1');
    const res = await fail(pool, job.id, job.fence, 'boom', { backoff: { baseMs: 10_000, factor: 2, maxMs: 60_000 } });
    expect(res.outcome).toBe('retry');
    const after = await getJob(pool, job.id);
    expect(after).toMatchObject({ status: 'queued', lockedBy: null, lastError: 'boom', attempts: 1 });
    expect(after!.runAt.getTime()).toBeGreaterThan(Date.now() + 4_000); // >= base/2
    // not claimable again until the backoff elapses
    expect(await claim(pool, { workerId: 'w2', leaseSeconds: 30 })).toHaveLength(0);
  });

  it('dead-letters the job once max attempts are used', async () => {
    await enqueue(pool, { type: 'a', maxAttempts: 2 });
    const tiny = { baseMs: 1, factor: 1, maxMs: 1 };

    const first = await claimOne('w1');
    expect((await fail(pool, first.id, first.fence, 'e1', { backoff: tiny })).outcome).toBe('retry');
    await pool.query("UPDATE jobs SET run_at = now() WHERE id = $1", [first.id]);

    const second = await claimOne('w1');
    expect(second.attempts).toBe(2);
    expect((await fail(pool, second.id, second.fence, 'e2')).outcome).toBe('dead');

    const dead = await getJob(pool, first.id);
    expect(dead).toMatchObject({ status: 'dead', lastError: 'e2' });
    expect(dead?.finishedAt).not.toBeNull();
  });

  it('dead-letters immediately for a non-retryable error', async () => {
    await enqueue(pool, { type: 'a', maxAttempts: 5 });
    const job = await claimOne('w1');
    expect((await fail(pool, job.id, job.fence, 'bad input', { retryable: false })).outcome).toBe('dead');
  });

  it('reports stale when the fence does not match', async () => {
    await enqueue(pool, { type: 'a' });
    const job = await claimOne('w1');
    expect((await fail(pool, job.id, job.fence + 1, 'x')).outcome).toBe('stale');
  });
});

describe('crash recovery (reaper + fencing)', () => {
  it('does nothing while leases are still valid', async () => {
    await enqueue(pool, { type: 'a' });
    await claimOne('w1');
    expect(await reapExpiredLeases(pool)).toEqual({ requeued: 0, dead: 0 });
  });

  it('requeues a job whose worker died, and a new worker can finish it', async () => {
    await enqueue(pool, { type: 'a' });
    const lost = await claimOne('crashed-worker');
    await expireLease(pool, lost.id);

    expect(await reapExpiredLeases(pool)).toEqual({ requeued: 1, dead: 0 });
    const requeued = await getJob(pool, lost.id);
    expect(requeued).toMatchObject({ status: 'queued', lockedBy: null });

    const retaken = await claimOne('healthy-worker');
    expect(retaken.id).toBe(lost.id);
    expect(retaken.fence).toBe(lost.fence + 1);
    expect(await complete(pool, retaken.id, retaken.fence)).toBe(true);

    const { rows } = await pool.query('SELECT fence, outcome FROM job_attempts WHERE job_id = $1 ORDER BY fence', [lost.id]);
    expect(rows.map((r) => r.outcome)).toEqual(['lease_expired', 'succeeded']);
  });

  it('fences out a zombie worker that wakes up after its job was reassigned', async () => {
    await enqueue(pool, { type: 'a' });
    const zombie = await claimOne('zombie');
    await expireLease(pool, zombie.id);
    await reapExpiredLeases(pool);
    const current = await claimOne('healthy');

    // The zombie (e.g. resumed after a long GC pause) tries every write with its old fence.
    expect(await complete(pool, zombie.id, zombie.fence)).toBe(false);
    expect(await heartbeat(pool, zombie.id, zombie.fence, 30)).toBe(false);
    expect((await fail(pool, zombie.id, zombie.fence, 'late')).outcome).toBe('stale');

    // The legitimate holder is unaffected and still succeeds.
    expect((await getJob(pool, current.id))?.status).toBe('running');
    expect(await complete(pool, current.id, current.fence)).toBe(true);
  });

  it('dead-letters a job that keeps killing workers (attempts exhausted)', async () => {
    await enqueue(pool, { type: 'poison', maxAttempts: 2 });
    for (let i = 0; i < 2; i++) {
      const job = await claimOne(`w${i}`);
      await expireLease(pool, job.id);
      const res = await reapExpiredLeases(pool);
      expect(res).toEqual(i === 0 ? { requeued: 1, dead: 0 } : { requeued: 0, dead: 1 });
    }
    const { rows } = await pool.query("SELECT status FROM jobs WHERE type = 'poison'");
    expect(rows[0].status).toBe('dead');
  });

  it('two reapers running at once never reap the same job twice', async () => {
    await pool.query(`INSERT INTO jobs (type) SELECT 'bulk' FROM generate_series(1, 50)`);
    const claimed = await claim(pool, { workerId: 'w', leaseSeconds: 30, limit: 50 });
    await pool.query("UPDATE jobs SET lease_expires_at = now() - interval '1 second' WHERE status = 'running'");
    const [a, b] = await Promise.all([reapExpiredLeases(pool, 50), reapExpiredLeases(pool, 50)]);
    expect(claimed).toHaveLength(50);
    expect(a.requeued + b.requeued).toBe(50);
  });
});
