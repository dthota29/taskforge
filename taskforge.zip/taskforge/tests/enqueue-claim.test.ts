import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { cancel, claim, complete, enqueue, getJob, replay } from '../src/core/index.js';
import type { Pool } from '../src/db/pool.js';
import { resetDb, setupDb } from './helpers.js';

let pool: Pool;
beforeAll(async () => {
  pool = await setupDb();
});
afterAll(async () => {
  await pool.end();
});
beforeEach(async () => {
  await resetDb(pool);
});

describe('enqueue', () => {
  it('applies defaults', async () => {
    const { job, created } = await enqueue(pool, { type: 'email' });
    expect(created).toBe(true);
    expect(job).toMatchObject({ queue: 'default', status: 'queued', priority: 0, attempts: 0, maxAttempts: 5, fence: 0 });
  });

  it('does not make a delayed job claimable until it is due', async () => {
    await enqueue(pool, { type: 'later', delayMs: 60_000 });
    expect(await claim(pool, { workerId: 'w1', leaseSeconds: 30 })).toHaveLength(0);
  });

  it('returns the existing job for a duplicate idempotency key', async () => {
    const a = await enqueue(pool, { type: 'pay', idempotencyKey: 'order-1', payload: { n: 1 } });
    const b = await enqueue(pool, { type: 'pay', idempotencyKey: 'order-1', payload: { n: 2 } });
    expect(a.created).toBe(true);
    expect(b.created).toBe(false);
    expect(b.job.id).toBe(a.job.id);
    expect(b.job.payload).toEqual({ n: 1 });
  });

  it('scopes idempotency keys per queue', async () => {
    const a = await enqueue(pool, { type: 't', queue: 'a', idempotencyKey: 'k' });
    const b = await enqueue(pool, { type: 't', queue: 'b', idempotencyKey: 'k' });
    expect(a.job.id).not.toBe(b.job.id);
  });

  it('creates exactly one job when 25 identical submits race', async () => {
    const results = await Promise.all(
      Array.from({ length: 25 }, () => enqueue(pool, { type: 'pay', idempotencyKey: 'race' })),
    );
    expect(new Set(results.map((r) => r.job.id)).size).toBe(1);
    expect(results.filter((r) => r.created)).toHaveLength(1);
    const { rows } = await pool.query('SELECT count(*)::int AS n FROM jobs');
    expect(rows[0].n).toBe(1);
  });

  it('rejects out-of-range values at the database', async () => {
    await expect(enqueue(pool, { type: 'x', priority: 500 })).rejects.toThrow();
    await expect(enqueue(pool, { type: 'x', maxAttempts: 0 })).rejects.toThrow();
  });
});

describe('claim', () => {
  it('leases the job, bumps fence and attempts, and records an attempt row', async () => {
    await enqueue(pool, { type: 'a' });
    const [job] = await claim(pool, { workerId: 'w1', leaseSeconds: 30 });
    expect(job).toMatchObject({ status: 'running', lockedBy: 'w1', fence: 1, attempts: 1 });
    expect(job?.leaseExpiresAt!.getTime()).toBeGreaterThan(Date.now());
    const { rows } = await pool.query('SELECT * FROM job_attempts WHERE job_id = $1', [job!.id]);
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ attempt: 1, worker_id: 'w1', outcome: null });
  });

  it('orders by priority, then run_at', async () => {
    const low = await enqueue(pool, { type: 'low', priority: 0, runAt: new Date(Date.now() - 3000) });
    const highLate = await enqueue(pool, { type: 'high-late', priority: 10, runAt: new Date(Date.now() - 1000) });
    const highEarly = await enqueue(pool, { type: 'high-early', priority: 10, runAt: new Date(Date.now() - 2000) });
    const claimed = await claim(pool, { workerId: 'w1', leaseSeconds: 30, limit: 3 });
    expect(claimed.map((j) => j.id)).toEqual([highEarly.job.id, highLate.job.id, low.job.id]);
  });

  it('only claims from the requested queues', async () => {
    await enqueue(pool, { type: 'a', queue: 'emails' });
    expect(await claim(pool, { workerId: 'w1', leaseSeconds: 30, queues: ['reports'] })).toHaveLength(0);
    expect(await claim(pool, { workerId: 'w1', leaseSeconds: 30, queues: ['emails'] })).toHaveLength(1);
  });

  it('claims the global top-priority jobs across several queues', async () => {
    const mk = (queue: string, priority: number) => enqueue(pool, { type: 't', queue, priority }).then((r) => r.job);
    await mk('a', 1);
    const b9 = await mk('b', 9);
    await mk('c', 5);
    const a7 = await mk('a', 7);
    const c8 = await mk('c', 8);
    await mk('z', 100); // not in the requested set
    const claimed = await claim(pool, { workerId: 'w', leaseSeconds: 30, queues: ['a', 'b', 'c'], limit: 3 });
    expect(claimed.map((j) => j.id)).toEqual([b9.id, c8.id, a7.id]);
    // the rows that lost the cut must still be claimable (their locks were not kept)
    const rest = await claim(pool, { workerId: 'w', leaseSeconds: 30, queues: ['a', 'b', 'c'], limit: 10 });
    expect(rest).toHaveLength(2);
  });

  it('walks jobs_claim_idx instead of scanning the backlog (guards a 40ms-per-claim regression)', async () => {
    await pool.query(`INSERT INTO jobs (type, priority) SELECT 'bulk', (g % 10)::smallint FROM generate_series(1, 5000) g`);
    await pool.query('ANALYZE jobs');
    const { rows } = await pool.query(
      `EXPLAIN SELECT id FROM jobs WHERE status = 'queued' AND queue = 'default' AND run_at <= now()
       ORDER BY priority DESC, run_at ASC, id ASC LIMIT 5 FOR UPDATE SKIP LOCKED`,
    );
    expect(rows.map((r) => r['QUERY PLAN']).join('\n')).toContain('jobs_claim_idx');
  });

  it('never hands the same job to two workers under concurrency', async () => {
    const total = 300;
    await pool.query(
      `INSERT INTO jobs (type) SELECT 'bulk' FROM generate_series(1, $1)`,
      [total],
    );
    const claimedIds: string[] = [];
    const worker = async (id: string) => {
      for (;;) {
        const jobs = await claim(pool, { workerId: id, leaseSeconds: 30, limit: 3 });
        if (jobs.length === 0) return;
        for (const j of jobs) claimedIds.push(j.id);
      }
    };
    await Promise.all(Array.from({ length: 10 }, (_, i) => worker(`w${i}`)));
    expect(claimedIds).toHaveLength(total);
    expect(new Set(claimedIds).size).toBe(total);
  });
});

describe('cancel and replay', () => {
  it('cancels a queued job but not a running one', async () => {
    const q = await enqueue(pool, { type: 'a' });
    expect(await cancel(pool, q.job.id)).toBe('cancelled');
    expect((await getJob(pool, q.job.id))?.status).toBe('cancelled');

    await enqueue(pool, { type: 'b' });
    const [running] = await claim(pool, { workerId: 'w1', leaseSeconds: 30 });
    expect(await cancel(pool, running!.id)).toBe('not_cancellable');
    expect(await cancel(pool, '00000000-0000-0000-0000-000000000000')).toBe('not_found');
  });

  it('replays only dead jobs, with a fresh attempt budget', async () => {
    const { job } = await enqueue(pool, { type: 'a', maxAttempts: 1 });
    await pool.query("UPDATE jobs SET status='dead', attempts=1, finished_at=now() WHERE id=$1", [job.id]);
    const replayed = await replay(pool, job.id);
    expect(replayed).toMatchObject({ status: 'queued', attempts: 0, finishedAt: null });

    const [c] = await claim(pool, { workerId: 'w1', leaseSeconds: 30 });
    await complete(pool, c!.id, c!.fence);
    expect(await replay(pool, job.id)).toBeNull(); // succeeded jobs cannot be replayed
  });
});
