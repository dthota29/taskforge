import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createLogger } from '../src/logger.js';
import { NonRetryableError } from '../src/worker/registry.js';
import type { JobContext } from '../src/worker/registry.js';
import { createWebhookHandler, isBlockedAddress } from '../src/worker/webhook.js';

let server: http.Server;
let base: string;
let lastRequest: { headers: http.IncomingHttpHeaders; body: string } | null = null;

beforeAll(async () => {
  server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      lastRequest = { headers: req.headers, body };
      const code = Number(req.url?.slice(1)) || 200;
      if (code === 302) res.setHeader('location', 'http://169.254.169.254/latest/meta-data');
      res.statusCode = code;
      res.end('x');
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(() => new Promise<void>((r) => server.close(() => r())));

const ctx = (): JobContext => ({
  jobId: 'job-123',
  attempt: 2,
  signal: new AbortController().signal,
  logger: createLogger('silent'),
});

describe('webhook handler', () => {
  const handler = createWebhookHandler({ allowPrivate: true });

  it('delivers the body with idempotency and attempt headers', async () => {
    const res = await handler.handle({ url: `${base}/200`, body: { hello: 'world' } }, ctx());
    expect(res).toEqual({ status: 200 });
    expect(lastRequest?.body).toBe('{"hello":"world"}');
    expect(lastRequest?.headers['idempotency-key']).toBe('job-123');
    expect(lastRequest?.headers['x-taskforge-attempt']).toBe('2');
  });

  it.each([500, 503, 429, 408])('retries on %i', async (code) => {
    const err = await handler.handle({ url: `${base}/${code}` }, ctx()).catch((e) => e);
    expect(err).toBeInstanceOf(Error);
    expect(err).not.toBeInstanceOf(NonRetryableError);
  });

  it.each([400, 404, 422])('does not retry on %i', async (code) => {
    await expect(handler.handle({ url: `${base}/${code}` }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
  });

  it('does not follow redirects', async () => {
    await expect(handler.handle({ url: `${base}/302` }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
  });

  it('rejects invalid payloads without retrying', async () => {
    await expect(handler.handle({ url: 'not a url' }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
    await expect(handler.handle({ url: 'file:///etc/passwd' }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
    await expect(handler.handle({ url: `${base}/200`, method: 'DELETE' }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
  });

  it('stops when the job signal aborts', async () => {
    const ac = new AbortController();
    const slow = http.createServer(() => undefined); // never responds
    await new Promise<void>((r) => slow.listen(0, '127.0.0.1', r));
    const url = `http://127.0.0.1:${(slow.address() as AddressInfo).port}/`;
    const p = handler.handle({ url }, { ...ctx(), signal: ac.signal });
    setTimeout(() => ac.abort(), 50);
    await expect(p).rejects.toThrow();
    slow.closeAllConnections();
    await new Promise<void>((r) => slow.close(() => r()));
  });
});

describe('SSRF protection (default handler)', () => {
  const guarded = createWebhookHandler();

  it.each([
    ['http://127.0.0.1/', 'loopback'],
    ['http://localhost/', 'loopback via DNS'],
    ['http://169.254.169.254/latest/meta-data', 'cloud metadata service'],
    ['http://10.0.0.5/', 'private 10/8'],
    ['http://192.168.1.1/', 'private 192.168/16'],
    ['http://172.16.0.1/', 'private 172.16/12'],
    ['http://[::1]/', 'IPv6 loopback'],
    ['http://[::ffff:127.0.0.1]/', 'IPv4-mapped IPv6 loopback'],
  ])('blocks %s (%s) permanently', async (url) => {
    await expect(guarded.handle({ url }, ctx())).rejects.toBeInstanceOf(NonRetryableError);
  });

  it('classifies addresses', () => {
    for (const ip of ['127.0.0.1', '10.1.2.3', '169.254.169.254', '100.64.0.1', '::1', 'fe80::1', 'fd00::1', '0.0.0.0']) {
      expect(isBlockedAddress(ip), ip).toBe(true);
    }
    for (const ip of ['8.8.8.8', '1.1.1.1', '93.184.216.34', '2606:4700:4700::1111']) {
      expect(isBlockedAddress(ip), ip).toBe(false);
    }
    expect(isBlockedAddress('not-an-ip')).toBe(true); // fail closed
  });
});
