import { describe, expect, it } from 'vitest';
import { backoffDelayMs } from '../src/core/backoff.js';

const opts = { baseMs: 1000, factor: 2, maxMs: 60_000 };

describe('backoffDelayMs', () => {
  it('grows exponentially (jitter at its minimum = half of the exponential value)', () => {
    expect(backoffDelayMs(1, opts, () => 0)).toBe(500);
    expect(backoffDelayMs(2, opts, () => 0)).toBe(1000);
    expect(backoffDelayMs(3, opts, () => 0)).toBe(2000);
  });

  it('stays within [exp/2, exp] for any jitter value', () => {
    expect(backoffDelayMs(3, opts, () => 0.999999)).toBeLessThanOrEqual(4000);
    expect(backoffDelayMs(3, opts, () => 0.5)).toBe(3000);
  });

  it('is capped at maxMs', () => {
    expect(backoffDelayMs(30, opts, () => 1)).toBe(60_000);
    expect(backoffDelayMs(30, opts, () => 0)).toBe(30_000);
  });

  it('treats attempt < 1 as the first attempt', () => {
    expect(backoffDelayMs(0, opts, () => 0)).toBe(500);
  });
});
