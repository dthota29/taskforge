import http from 'node:http';
import client from 'prom-client';
import { getStats } from './core/stats.js';
import type { Pool } from './db/pool.js';
import type { Logger } from './logger.js';

export type JobOutcome = 'succeeded' | 'retried' | 'dead' | 'stale' | 'lease_lost' | 'released' | 'error';

/**
 * Label discipline: only low-cardinality labels. Job `type` is used solely for types that have a
 * registered handler (anything else is reported as "unknown"), and user-supplied values such as
 * queue names or URLs are never used as labels on request-driven series.
 */
export function createMetrics() {
  const registry = new client.Registry();
  client.collectDefaultMetrics({ register: registry });
  const reg = [registry];
  // The worker points this at its in-flight counter once it exists; the gauge reads it at scrape time.
  const inflightSource = { read: () => 0 };

  return {
    registry,
    inflightSource,
    // API
    httpDuration: new client.Histogram({
      name: 'taskforge_http_request_duration_seconds',
      help: 'HTTP request latency by route template and status',
      labelNames: ['method', 'route', 'status'],
      buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
      registers: reg,
    }),
    jobsEnqueued: new client.Counter({
      name: 'taskforge_jobs_enqueued_total',
      help: 'Jobs submitted through the API (result: created | duplicate)',
      labelNames: ['result'],
      registers: reg,
    }),
    rateLimited: new client.Counter({
      name: 'taskforge_rate_limited_total',
      help: 'Requests rejected by the rate limiter',
      labelNames: ['scope'],
      registers: reg,
    }),
    authFailures: new client.Counter({
      name: 'taskforge_auth_failures_total',
      help: 'Requests rejected for a missing, malformed or unknown API key',
      registers: reg,
    }),
    // Worker
    jobsProcessed: new client.Counter({
      name: 'taskforge_jobs_processed_total',
      help: 'Job attempts finished by this worker, by handler type and outcome',
      labelNames: ['type', 'outcome'],
      registers: reg,
    }),
    jobDuration: new client.Histogram({
      name: 'taskforge_job_duration_seconds',
      help: 'Wall time of a job attempt, by handler type',
      labelNames: ['type'],
      buckets: [0.01, 0.05, 0.1, 0.5, 1, 5, 15, 60, 300],
      registers: reg,
    }),
    claimDuration: new client.Histogram({
      name: 'taskforge_claim_duration_seconds',
      help: 'Latency of the claim query (the scheduler hot path)',
      buckets: [0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 1],
      registers: reg,
    }),
    inflight: new client.Gauge({
      name: 'taskforge_worker_inflight_jobs',
      help: 'Jobs currently executing in this worker',
      registers: reg,
      collect() {
        this.set(inflightSource.read());
      },
    }),
    reaped: new client.Counter({
      name: 'taskforge_reaped_jobs_total',
      help: 'Jobs recovered from expired leases (result: requeued | dead)',
      labelNames: ['result'],
      registers: reg,
    }),
    // Scheduler
    isLeader: new client.Gauge({
      name: 'taskforge_scheduler_is_leader',
      help: '1 if this replica currently holds scheduler leadership',
      registers: reg,
    }),
    schedulesFired: new client.Counter({
      name: 'taskforge_schedules_fired_total',
      help: 'Cron jobs created',
      registers: reg,
    }),
    jobsPruned: new client.Counter({
      name: 'taskforge_jobs_pruned_total',
      help: 'Finished jobs deleted by the retention task',
      registers: reg,
    }),
  };
}

export type Metrics = ReturnType<typeof createMetrics>;

/** Hooks the Worker calls; keeps the worker free of any prom-client dependency. */
export interface WorkerMetrics {
  jobFinished(type: string, outcome: JobOutcome, seconds: number): void;
  claimed(seconds: number): void;
}

export function workerMetrics(m: Metrics): WorkerMetrics {
  return {
    jobFinished(type, outcome, seconds) {
      m.jobsProcessed.inc({ type, outcome });
      m.jobDuration.observe({ type }, seconds);
    },
    claimed(seconds) {
      m.claimDuration.observe(seconds);
    },
  };
}

/**
 * Queue-depth gauges computed from the database at scrape time. Register these in ONE kind of
 * process only (the API): every replica reports the same global numbers, so dashboards should
 * aggregate with max(), not sum().
 */
export function registerQueueGauges(m: Metrics, pool: Pool): void {
  const labels = ['queue', 'state'];
  const depth = new client.Gauge({
    name: 'taskforge_queue_jobs',
    help: 'Non-terminal jobs by queue and state (queued | ready | running)',
    labelNames: labels,
    registers: [m.registry],
    async collect() {
      const stats = await getStats(pool);
      this.reset();
      for (const q of stats.queues) {
        this.set({ queue: q.queue, state: 'queued' }, q.queued);
        this.set({ queue: q.queue, state: 'ready' }, q.ready);
        this.set({ queue: q.queue, state: 'running' }, q.running);
      }
    },
  });
  void depth;
  new client.Gauge({
    name: 'taskforge_queue_oldest_ready_age_seconds',
    help: 'Age of the oldest ready job per queue: the queue-lag SLO signal',
    labelNames: ['queue'],
    registers: [m.registry],
    async collect() {
      const stats = await getStats(pool);
      this.reset();
      for (const q of stats.queues) this.set({ queue: q.queue }, q.oldestReadyAgeSeconds);
    },
  });
  new client.Gauge({
    name: 'taskforge_dead_jobs',
    help: 'Jobs currently in the dead-letter queue',
    registers: [m.registry],
    async collect() {
      this.set((await getStats(pool)).dead);
    },
  });
}

/** Minimal internal HTTP server: /metrics for Prometheus and /healthz for liveness probes. */
export function startMetricsServer(registry: client.Registry, port: number, logger: Logger): http.Server {
  const server = http.createServer((req, res) => {
    if (req.url === '/healthz') {
      res.writeHead(200, { 'content-type': 'text/plain' }).end('ok');
    } else if (req.url === '/metrics') {
      registry
        .metrics()
        .then((body) => res.writeHead(200, { 'content-type': registry.contentType }).end(body))
        .catch((err) => {
          logger.error({ err }, 'failed to render metrics');
          res.writeHead(500).end('error');
        });
    } else {
      res.writeHead(404).end();
    }
  });
  server.listen(port, () => logger.info({ port }, 'metrics server listening'));
  return server;
}
