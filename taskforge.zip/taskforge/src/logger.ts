import { pino } from 'pino';
import type { Logger } from 'pino';

export type { Logger };

export function createLogger(level: string = 'info', base: Record<string, unknown> = {}): Logger {
  return pino({ level, base: { service: 'taskforge', ...base }, timestamp: pino.stdTimeFunctions.isoTime });
}
