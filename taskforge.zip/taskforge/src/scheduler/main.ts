import { runLoop } from '../core/loop.js';
import { pruneFinishedJobs } from '../core/retention.js';
import { loadConfig } from '../config.js';
import { createPool } from '../db/pool.js';
import { createLogger } from '../logger.js';
import { createMetrics, startMetricsServer } from '../metrics.js';
import { fireDueSchedules } from './cron.js';
import { LeaderElection } from './leader.js';

const SCHEDULER_LOCK_ID = 727_002;
const PRUNE_EVERY_MS = 60_000;

const cfg = loadConfig();
const logger = createLogger(cfg.LOG_LEVEL, { role: 'scheduler' });
const pool = createPool(cfg.DATABASE_URL, 4);
const metrics = createMetrics();
const metricsServer = startMetricsServer(metrics.registry, cfg.METRICS_PORT, logger);
const leader = new LeaderElection(pool, SCHEDULER_LOCK_ID, logger);

let lastPrune = 0;
const loop = runLoop(
  'scheduler',
  cfg.SCHEDULER_TICK_SECONDS * 1000,
  async () => {
    const isLeader = await leader.tryAcquire();
    metrics.isLeader.set(isLeader ? 1 : 0);
    if (!isLeader) return; // standby replica
    const fired = await fireDueSchedules(pool);
    if (fired > 0) {
      metrics.schedulesFired.inc(fired);
      logger.info({ fired }, 'fired due schedules');
    }
    if (Date.now() - lastPrune >= PRUNE_EVERY_MS) {
      lastPrune = Date.now();
      const pruned = await pruneFinishedJobs(pool, {
        finishedDays: cfg.RETENTION_DAYS,
        deadDays: cfg.DEAD_RETENTION_DAYS,
      });
      if (pruned > 0) {
        metrics.jobsPruned.inc(pruned);
        logger.info({ pruned }, 'pruned old jobs');
      }
    }
  },
  logger,
);

logger.info('scheduler started (standby until it wins leader election)');

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'shutting down');
  setTimeout(() => process.exit(1), 15_000).unref();
  await loop.stop();
  await leader.release(); // hand leadership over immediately instead of waiting for the connection to close
  metricsServer.close();
  await pool.end();
  process.exit(0);
}
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('unhandledRejection', (err) => {
  logger.fatal({ err }, 'unhandled rejection');
  process.exit(1);
});
