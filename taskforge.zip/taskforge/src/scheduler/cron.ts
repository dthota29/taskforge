import { withTransaction } from '../db/pool.js';
import type { Pool } from '../db/pool.js';
import { enqueue } from '../core/jobs.js';
import { nextFireAfter } from '../core/schedules.js';
import type { ScheduleRow } from '../core/schedules.js';

/**
 * Turn due cron schedules into jobs. Returns the number of jobs created.
 *
 * Everything for one schedule (insert the job, advance next_fire_at) happens in one transaction
 * under a row lock, so a crash cannot fire without advancing or advance without firing.
 *
 * Misfire policy: "fire once". After downtime, a schedule that missed many fire times creates a
 * single job for the oldest missed time and then jumps to the next future time. This avoids a
 * thundering herd of catch-up jobs; jobs that need every tick should be idempotent per tick.
 */
export async function fireDueSchedules(pool: Pool, batchSize = 100): Promise<number> {
  return withTransaction(pool, async (c) => {
    const { rows } = await c.query<ScheduleRow & { db_now: Date }>(
      `SELECT *, now() AS db_now FROM schedules
       WHERE enabled AND next_fire_at <= now()
       ORDER BY next_fire_at
       LIMIT $1
       FOR UPDATE SKIP LOCKED`,
      [batchSize],
    );
    let created = 0;
    for (const s of rows) {
      const res = await enqueue(c, {
        type: s.type,
        payload: s.payload,
        queue: s.queue,
        priority: s.priority,
        maxAttempts: s.max_attempts,
        scheduleId: s.id,
        scheduledFor: s.next_fire_at,
      });
      if (res.created) created++;
      await c.query('UPDATE schedules SET next_fire_at = $2, last_fired_at = $3 WHERE id = $1', [
        s.id,
        nextFireAfter(s.cron_expr, s.timezone, s.db_now),
        s.db_now,
      ]);
    }
    return created;
  });
}
