import type pg from 'pg';
import type { Pool } from '../db/pool.js';
import type { Logger } from '../logger.js';

/**
 * Leader election with a Postgres session-level advisory lock.
 *
 * The lock lives on one dedicated connection. If the process dies or the connection drops,
 * Postgres releases the lock automatically and another replica takes over on its next tick,
 * so there is no TTL to tune and no separate coordination service.
 *
 * Leadership only avoids duplicate work. Correctness never depends on it: the unique index on
 * (schedule_id, scheduled_for) still prevents a double fire if two leaders briefly coexist.
 */
export class LeaderElection {
  private client: pg.PoolClient | null = null;

  constructor(
    private readonly pool: Pool,
    private readonly lockId: number,
    private readonly logger: Logger,
  ) {}

  get isLeader(): boolean {
    return this.client !== null;
  }

  /** Try to become (or confirm we still are) the leader. Call on every tick. */
  async tryAcquire(): Promise<boolean> {
    if (this.client) {
      try {
        await this.client.query('SELECT 1'); // liveness check: a dead connection means the lock is gone
        return true;
      } catch (err) {
        this.logger.warn({ err }, 'leader connection lost, stepping down');
        this.drop(true);
      }
    }
    let client: pg.PoolClient;
    try {
      client = await this.pool.connect();
    } catch (err) {
      this.logger.warn({ err }, 'could not get a connection for leader election');
      return false;
    }
    try {
      const { rows } = await client.query<{ locked: boolean }>('SELECT pg_try_advisory_lock($1) AS locked', [
        this.lockId,
      ]);
      if (rows[0]?.locked) {
        client.on('error', () => this.drop(true));
        this.client = client;
        this.logger.info('acquired scheduler leadership');
        return true;
      }
      client.release();
      return false;
    } catch (err) {
      client.release(true);
      this.logger.warn({ err }, 'leader election query failed');
      return false;
    }
  }

  async release(): Promise<void> {
    const client = this.client;
    if (!client) return;
    this.client = null;
    try {
      await client.query('SELECT pg_advisory_unlock($1)', [this.lockId]);
      client.release();
    } catch {
      client.release(true); // destroying the connection releases the lock anyway
    }
  }

  private drop(destroy: boolean): void {
    const client = this.client;
    this.client = null;
    client?.release(destroy);
  }
}
