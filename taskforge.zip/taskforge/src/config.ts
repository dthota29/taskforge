import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  DB_POOL_MAX: z.coerce.number().int().min(1).default(10),
  WORKER_CONCURRENCY: z.coerce.number().int().min(1).default(10),
  LEASE_SECONDS: z.coerce.number().int().min(5).default(30),
  HEARTBEAT_SECONDS: z.coerce.number().int().min(1).default(10),
  WORKER_QUEUES: z
    .string()
    .default('default')
    .transform((s) => s.split(',').map((q) => q.trim()).filter(Boolean)),
  POLL_INTERVAL_MS: z.coerce.number().int().min(10).default(500),
  DRAIN_TIMEOUT_SECONDS: z.coerce.number().int().min(1).default(25),
  REAPER_INTERVAL_SECONDS: z.coerce.number().int().min(1).default(5),
  SCHEDULER_TICK_SECONDS: z.coerce.number().int().min(1).default(1),
  RETENTION_DAYS: z.coerce.number().int().min(0).default(7),
  DEAD_RETENTION_DAYS: z.coerce.number().int().min(0).default(30),
  // API
  /** Requests per minute per API key / per client IP (in-memory, so per replica). */
  KEY_RATE_LIMIT_PER_MINUTE: z.coerce.number().int().min(1).default(600),
  IP_RATE_LIMIT_PER_MINUTE: z.coerce.number().int().min(1).default(1200),
  /** Set to true when running behind a trusted proxy/ingress so the real client IP is used. */
  TRUST_PROXY: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),
  /** Optional admin key (from a secret) that is upserted at API startup. Format: tf_ + 32-128 URL-safe chars. */
  ADMIN_API_KEY: z
    .string()
    .regex(/^tf_[A-Za-z0-9_-]{32,128}$/, 'must look like tf_ followed by 32-128 URL-safe characters')
    .optional(),
  /** Internal port for /metrics and /healthz (keep it off the public ingress). */
  METRICS_PORT: z.coerce.number().int().min(1).max(65535).default(9100),
  /** After SIGTERM, report not-ready for this long before closing so load balancers stop sending traffic. */
  SHUTDOWN_DELAY_SECONDS: z.coerce.number().int().min(0).default(5),
  /** Apply pending migrations at API startup. Convenient for single-container setups; Helm runs a migration job instead. */
  RUN_MIGRATIONS: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),
  // Webhook handler SSRF guard. Only enable for local development.
  ALLOW_PRIVATE_WEBHOOKS: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),
});

export type Config = z.infer<typeof schema>;

/** Parse and validate env once at startup; fail fast with a readable message. */
export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const parsed = schema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
    throw new Error(`Invalid configuration: ${issues}`);
  }
  const cfg = parsed.data;
  if (cfg.HEARTBEAT_SECONDS * 2 >= cfg.LEASE_SECONDS) {
    throw new Error('Invalid configuration: HEARTBEAT_SECONDS must be less than half of LEASE_SECONDS');
  }
  return cfg;
}
