export interface RateDecision {
  allowed: boolean;
  limit: number;
  remaining: number;
  retryAfterSeconds: number;
}

interface Bucket {
  tokens: number;
  updatedAt: number;
}

/**
 * Token bucket: refills continuously at `perMinute / 60` tokens a second up to `burst`.
 * Allows short bursts but caps the sustained rate, with no window-boundary spikes.
 *
 * State is in memory, so the limit is per replica (N replicas allow up to N x the limit). That is
 * a deliberate trade-off to keep Redis out of the dependency list; a global limit belongs at the
 * ingress/gateway. Memory is bounded: the oldest entries are evicted past `maxKeys`.
 */
export class RateLimiter {
  private readonly buckets = new Map<string, Bucket>();
  private readonly refillPerMs: number;

  constructor(
    private readonly perMinute: number,
    private readonly burst: number = perMinute,
    private readonly maxKeys = 50_000,
    private readonly now: () => number = Date.now,
  ) {
    this.refillPerMs = perMinute / 60_000;
  }

  take(key: string): RateDecision {
    const t = this.now();
    let b = this.buckets.get(key);
    if (b) {
      b.tokens = Math.min(this.burst, b.tokens + (t - b.updatedAt) * this.refillPerMs);
      b.updatedAt = t;
      // Re-insert so Map order approximates least-recently-used for eviction.
      this.buckets.delete(key);
    } else {
      b = { tokens: this.burst, updatedAt: t };
      if (this.buckets.size >= this.maxKeys) {
        const oldest = this.buckets.keys().next().value;
        if (oldest !== undefined) this.buckets.delete(oldest);
      }
    }
    this.buckets.set(key, b);

    if (b.tokens >= 1) {
      b.tokens -= 1;
      return { allowed: true, limit: this.perMinute, remaining: Math.floor(b.tokens), retryAfterSeconds: 0 };
    }
    const wait = Math.ceil((1 - b.tokens) / this.refillPerMs / 1000);
    return { allowed: false, limit: this.perMinute, remaining: 0, retryAfterSeconds: Math.max(1, wait) };
  }

  get size(): number {
    return this.buckets.size;
  }
}
