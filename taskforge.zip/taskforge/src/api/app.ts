import { randomUUID } from 'node:crypto';
import Fastify from 'fastify';
import type { FastifyBaseLogger, FastifyError, FastifyInstance } from 'fastify';
import { ZodError } from 'zod';
import { API_KEY_PATTERN, findApiKey, touchApiKey } from '../core/apikeys.js';
import type { ApiKeyRecord, Scope } from '../core/apikeys.js';
import { InvalidScheduleError, ScheduleConflictError } from '../core/schedules.js';
import type { Pool } from '../db/pool.js';
import type { Logger } from '../logger.js';
import type { Metrics } from '../metrics.js';
import { ApiError } from './errors.js';
import type { ErrorBody } from './errors.js';
import { buildOpenApi } from './openapi.js';
import { RateLimiter } from './ratelimit.js';
import { buildRoutes } from './routes.js';

declare module 'fastify' {
  interface FastifyContextConfig {
    scope?: Scope;
    /** No authentication, no rate limiting (health probes, API description). */
    public?: boolean;
  }
  interface FastifyRequest {
    apiKey?: ApiKeyRecord;
  }
}

export interface AppDeps {
  pool: Pool;
  logger: Logger;
  metrics: Metrics;
  limits: { ipPerMinute: number; keyPerMinute: number };
  trustProxy: boolean;
  /** Flipped by the process on SIGTERM so /readyz fails before the server closes. */
  state: { shuttingDown: boolean };
  version?: string;
}

const LAST_USED_THROTTLE_MS = 60_000;

export async function buildApp(deps: AppDeps): Promise<FastifyInstance> {
  const { pool, metrics, state } = deps;
  const app = Fastify({
    loggerInstance: deps.logger as FastifyBaseLogger,
    trustProxy: deps.trustProxy,
    bodyLimit: 256 * 1024,
    requestTimeout: 30_000,
    // Longer than common load-balancer idle timeouts (60s) so the LB never reuses a connection we closed.
    keepAliveTimeout: 65_000,
    forceCloseConnections: 'idle',
    genReqId: (req) => {
      const h = req.headers['x-request-id'];
      return typeof h === 'string' && /^[\w.-]{8,64}$/.test(h) ? h : randomUUID();
    },
  });

  const ipLimiter = new RateLimiter(deps.limits.ipPerMinute);
  const keyLimiter = new RateLimiter(deps.limits.keyPerMinute);
  const lastTouched = new Map<string, number>();

  const unauthorized = (reply: { header: (k: string, v: string) => unknown }) => {
    metrics.authFailures.inc();
    reply.header('www-authenticate', 'Bearer');
    return new ApiError(401, 'unauthorized', 'missing or invalid API key');
  };

  // Order matters: cheap IP limit first (protects the auth lookup), then authenticate, then the
  // per-key limit. A route without a declared scope is denied: secure by default.
  app.addHook('onRequest', async (req, reply) => {
    const cfg = req.routeOptions.config;
    if (req.is404 || cfg.public) return;

    const ip = ipLimiter.take(req.ip);
    if (!ip.allowed) {
      metrics.rateLimited.inc({ scope: 'ip' });
      reply.header('retry-after', String(ip.retryAfterSeconds));
      throw new ApiError(429, 'rate_limited', 'too many requests from this address');
    }

    const match = /^Bearer (\S+)$/.exec(req.headers.authorization ?? '');
    const presented = match?.[1];
    if (!presented || !API_KEY_PATTERN.test(presented)) throw unauthorized(reply);
    const key = await findApiKey(pool, presented);
    if (!key) throw unauthorized(reply);

    const required = cfg.scope;
    if (!required) throw new ApiError(403, 'forbidden', 'route has no access policy');
    if (!key.scopes.includes('admin') && !key.scopes.includes(required)) {
      throw new ApiError(403, 'forbidden', `API key lacks required scope "${required}"`);
    }
    req.apiKey = key;

    const decision = keyLimiter.take(key.id);
    reply.header('ratelimit-limit', String(decision.limit));
    reply.header('ratelimit-remaining', String(decision.remaining));
    if (!decision.allowed) {
      metrics.rateLimited.inc({ scope: 'key' });
      reply.header('retry-after', String(decision.retryAfterSeconds));
      throw new ApiError(429, 'rate_limited', 'rate limit exceeded for this API key');
    }

    // last_used_at is informational: write it at most once a minute per key, never on the hot path.
    const now = Date.now();
    if (now - (lastTouched.get(key.id) ?? 0) > LAST_USED_THROTTLE_MS) {
      lastTouched.set(key.id, now);
      touchApiKey(pool, key.id).catch((err) => req.log.warn({ err }, 'failed to update last_used_at'));
    }
  });

  app.addHook('onSend', async (req, reply) => {
    reply.header('x-request-id', req.id);
    reply.header('x-content-type-options', 'nosniff');
    reply.header('cache-control', 'no-store');
  });

  app.addHook('onResponse', async (req, reply) => {
    // Route template (never the raw URL) keeps label cardinality bounded.
    const route = req.is404 ? 'unmatched' : (req.routeOptions.url ?? 'unmatched');
    metrics.httpDuration.observe(
      { method: req.method, route, status: String(reply.statusCode) },
      reply.elapsedTime / 1000,
    );
  });

  app.setErrorHandler((err: FastifyError, req, reply) => {
    let status = 500;
    let code = 'internal_error';
    let message = 'internal server error';
    let details: unknown;

    if (err instanceof ZodError) {
      status = 400;
      code = 'validation_error';
      message = 'request validation failed';
      details = err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
    } else if (err instanceof ApiError) {
      ({ statusCode: status, code, message, details } = err);
    } else if (err instanceof InvalidScheduleError) {
      status = 400;
      code = 'invalid_schedule';
      message = err.message;
    } else if (err instanceof ScheduleConflictError) {
      status = 409;
      code = 'conflict';
      message = err.message;
    } else if (typeof err.statusCode === 'number' && err.statusCode >= 400 && err.statusCode < 500) {
      // Fastify's own client errors: malformed JSON, oversized body, unsupported media type...
      status = err.statusCode;
      code = status === 413 ? 'payload_too_large' : 'bad_request';
      message = err.message;
    } else {
      // Never leak internals to the client; the request id lets support find the log line.
      req.log.error({ err }, 'unhandled error');
    }

    const body: ErrorBody = { error: { code, message, requestId: req.id, ...(details === undefined ? {} : { details }) } };
    return reply.code(status).send(body);
  });

  app.setNotFoundHandler((req, reply) => {
    const body: ErrorBody = { error: { code: 'not_found', message: 'route not found', requestId: req.id } };
    return reply.code(404).send(body);
  });

  // ---- public operational endpoints ----
  const quiet = { public: true } as const;
  app.get('/healthz', { config: quiet, logLevel: 'warn' }, async () => ({ status: 'ok' }));

  app.get('/readyz', { config: quiet, logLevel: 'warn' }, async (_req, reply) => {
    if (state.shuttingDown) return reply.code(503).send({ status: 'shutting_down' });
    let timer: NodeJS.Timeout | undefined;
    try {
      await Promise.race([
        pool.query('SELECT 1'),
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error('database check timed out')), 2_000);
        }),
      ]);
      return { status: 'ok' };
    } catch {
      return reply.code(503).send({ status: 'database_unavailable' });
    } finally {
      clearTimeout(timer);
    }
  });

  // ---- v1 API (table-driven: also feeds the OpenAPI document) ----
  const routes = buildRoutes({ pool, metrics });
  for (const r of routes) {
    app.route({
      method: r.method.toUpperCase() as 'GET' | 'POST' | 'PATCH' | 'DELETE',
      url: r.path,
      config: { scope: r.scope },
      handler: r.handler,
    });
  }

  const spec = buildOpenApi(routes, deps.version ?? '0.1.0');
  app.get('/openapi.json', { config: quiet }, async () => spec);

  return app;
}
