import type { FastifyReply, FastifyRequest } from 'fastify';
import type { ZodType } from 'zod';
import {
  cancel,
  createApiKey,
  createSchedule,
  deleteSchedule,
  enqueue,
  getJob,
  getSchedule,
  getStats,
  listApiKeys,
  listAttempts,
  listJobs,
  listSchedules,
  replay,
  revokeApiKey,
  setScheduleEnabled,
} from '../core/index.js';
import type { Scope } from '../core/apikeys.js';
import type { Pool } from '../db/pool.js';
import type { Metrics } from '../metrics.js';
import { ApiError, notFound } from './errors.js';
import {
  attemptDto,
  createKeyBody,
  createScheduleBody,
  decodeCursor,
  dlqQuery,
  encodeCursor,
  enqueueBody,
  idParams,
  jobDto,
  keyDto,
  listJobsQuery,
  patchScheduleBody,
  scheduleDto,
} from './schemas.js';
import { z } from 'zod';

/**
 * Each route is declared once, here. The same table registers the Fastify handlers and generates
 * the OpenAPI document, so the published contract cannot drift from the implementation.
 */
export interface RouteDef {
  method: 'get' | 'post' | 'patch' | 'delete';
  /** Fastify-style path, e.g. /v1/jobs/:id */
  path: string;
  scope: Scope;
  tag: string;
  summary: string;
  params?: ZodType;
  query?: ZodType;
  body?: ZodType;
  /** Documented success responses: [status, description] */
  success: Array<[number, string]>;
  handler: (req: FastifyRequest, reply: FastifyReply) => Promise<unknown>;
}

const parse = <T extends ZodType>(schema: T, data: unknown): z.infer<T> => schema.parse(data);
const idOf = (req: FastifyRequest) => parse(idParams, req.params).id;

const idempotencyHeader = z.string().min(1).max(255);

export function buildRoutes(deps: { pool: Pool; metrics: Metrics }): RouteDef[] {
  const { pool, metrics } = deps;

  async function listResponse(opts: Parameters<typeof listJobs>[1]) {
    const page = await listJobs(pool, opts);
    return { jobs: page.jobs.map(jobDto), nextCursor: page.nextCursor ? encodeCursor(page.nextCursor) : null };
  }

  function cursorOf(raw?: string) {
    if (raw === undefined) return undefined;
    const c = decodeCursor(raw);
    if (!c) throw new ApiError(400, 'invalid_cursor', 'cursor is malformed or expired');
    return c;
  }

  return [
    // ---------------------------------------------------------------- jobs
    {
      method: 'post',
      path: '/v1/jobs',
      scope: 'jobs:write',
      tag: 'Jobs',
      summary: 'Submit a job. Idempotent when an idempotency key is supplied.',
      body: enqueueBody,
      success: [
        [201, 'Job created'],
        [200, 'A job with this idempotency key already exists; it is returned unchanged'],
      ],
      async handler(req, reply) {
        const body = parse(enqueueBody, req.body ?? {});
        const header = req.headers['idempotency-key'];
        const key = body.idempotencyKey ?? (header === undefined ? undefined : parse(idempotencyHeader, header));
        const { job, created } = await enqueue(pool, {
          type: body.type,
          payload: body.payload,
          queue: body.queue,
          priority: body.priority,
          delayMs: body.delayMs,
          runAt: body.runAt ? new Date(body.runAt) : undefined,
          maxAttempts: body.maxAttempts,
          idempotencyKey: key,
        });
        metrics.jobsEnqueued.inc({ result: created ? 'created' : 'duplicate' });
        if (!created) reply.header('idempotent-replay', 'true');
        return reply.code(created ? 201 : 200).send(jobDto(job));
      },
    },
    {
      method: 'get',
      path: '/v1/jobs',
      scope: 'jobs:read',
      tag: 'Jobs',
      summary: 'List jobs, newest first, with keyset pagination.',
      query: listJobsQuery,
      success: [[200, 'A page of jobs plus nextCursor (null on the last page)']],
      async handler(req) {
        const q = parse(listJobsQuery, req.query);
        return listResponse({ status: q.status, queue: q.queue, type: q.type, limit: q.limit, after: cursorOf(q.cursor) });
      },
    },
    {
      method: 'get',
      path: '/v1/jobs/:id',
      scope: 'jobs:read',
      tag: 'Jobs',
      summary: 'Get one job.',
      params: idParams,
      success: [[200, 'The job']],
      async handler(req) {
        const job = await getJob(pool, idOf(req));
        if (!job) throw notFound('job');
        return jobDto(job);
      },
    },
    {
      method: 'get',
      path: '/v1/jobs/:id/attempts',
      scope: 'jobs:read',
      tag: 'Jobs',
      summary: 'Execution history of a job: which worker ran each attempt and how it ended.',
      params: idParams,
      success: [[200, 'Attempts in order']],
      async handler(req) {
        const id = idOf(req);
        if (!(await getJob(pool, id))) throw notFound('job');
        return { attempts: (await listAttempts(pool, id)).map(attemptDto) };
      },
    },
    {
      method: 'post',
      path: '/v1/jobs/:id/cancel',
      scope: 'jobs:write',
      tag: 'Jobs',
      summary: 'Cancel a queued job. Running and finished jobs cannot be cancelled (409).',
      params: idParams,
      success: [[200, 'The cancelled job']],
      async handler(req) {
        const id = idOf(req);
        const outcome = await cancel(pool, id);
        if (outcome === 'not_found') throw notFound('job');
        if (outcome === 'not_cancellable') {
          throw new ApiError(409, 'conflict', 'only queued jobs can be cancelled; this job is running or already finished');
        }
        return jobDto((await getJob(pool, id))!);
      },
    },
    {
      method: 'post',
      path: '/v1/jobs/:id/replay',
      scope: 'jobs:write',
      tag: 'Jobs',
      summary: 'Move a dead-lettered job back to the queue with a fresh attempt budget.',
      params: idParams,
      success: [[200, 'The re-queued job']],
      async handler(req) {
        const id = idOf(req);
        const job = await replay(pool, id);
        if (job) return jobDto(job);
        if (!(await getJob(pool, id))) throw notFound('job');
        throw new ApiError(409, 'conflict', 'only dead-lettered jobs can be replayed');
      },
    },
    {
      method: 'get',
      path: '/v1/dead-letter-queue',
      scope: 'jobs:read',
      tag: 'Jobs',
      summary: 'Jobs that exhausted their retries, newest first.',
      query: dlqQuery,
      success: [[200, 'A page of dead-lettered jobs']],
      async handler(req) {
        const q = parse(dlqQuery, req.query);
        return listResponse({ status: 'dead', queue: q.queue, type: q.type, limit: q.limit, after: cursorOf(q.cursor) });
      },
    },
    {
      method: 'get',
      path: '/v1/stats',
      scope: 'jobs:read',
      tag: 'Jobs',
      summary: 'Backlog per queue (queued, ready, running, oldest ready age) and dead-letter count.',
      success: [[200, 'Current queue statistics']],
      async handler() {
        return getStats(pool);
      },
    },

    // ----------------------------------------------------------- schedules
    {
      method: 'post',
      path: '/v1/schedules',
      scope: 'schedules:write',
      tag: 'Schedules',
      summary: 'Create a cron schedule. Each fire time becomes one job.',
      body: createScheduleBody,
      success: [[201, 'Schedule created']],
      async handler(req, reply) {
        const b = parse(createScheduleBody, req.body ?? {});
        const s = await createSchedule(pool, { ...b, cron: b.cron });
        return reply.code(201).send(scheduleDto(s));
      },
    },
    {
      method: 'get',
      path: '/v1/schedules',
      scope: 'schedules:read',
      tag: 'Schedules',
      summary: 'List schedules.',
      success: [[200, 'All schedules']],
      async handler() {
        return { schedules: (await listSchedules(pool)).map(scheduleDto) };
      },
    },
    {
      method: 'get',
      path: '/v1/schedules/:id',
      scope: 'schedules:read',
      tag: 'Schedules',
      summary: 'Get one schedule.',
      params: idParams,
      success: [[200, 'The schedule']],
      async handler(req) {
        const s = await getSchedule(pool, idOf(req));
        if (!s) throw notFound('schedule');
        return scheduleDto(s);
      },
    },
    {
      method: 'patch',
      path: '/v1/schedules/:id',
      scope: 'schedules:write',
      tag: 'Schedules',
      summary: 'Enable or disable a schedule. Re-enabling skips the missed backlog.',
      params: idParams,
      body: patchScheduleBody,
      success: [[200, 'The updated schedule']],
      async handler(req) {
        const { enabled } = parse(patchScheduleBody, req.body ?? {});
        const s = await setScheduleEnabled(pool, idOf(req), enabled);
        if (!s) throw notFound('schedule');
        return scheduleDto(s);
      },
    },
    {
      method: 'delete',
      path: '/v1/schedules/:id',
      scope: 'schedules:write',
      tag: 'Schedules',
      summary: 'Delete a schedule. Jobs it already created are kept.',
      params: idParams,
      success: [[204, 'Deleted']],
      async handler(req, reply) {
        if (!(await deleteSchedule(pool, idOf(req)))) throw notFound('schedule');
        return reply.code(204).send();
      },
    },

    // ------------------------------------------------------------ api keys
    {
      method: 'post',
      path: '/v1/api-keys',
      scope: 'admin',
      tag: 'API keys',
      summary: 'Create an API key. The key is shown once in this response and cannot be retrieved again.',
      body: createKeyBody,
      success: [[201, 'Key created; includes the raw key']],
      async handler(req, reply) {
        const b = parse(createKeyBody, req.body ?? {});
        const { record, key } = await createApiKey(pool, { name: b.name, scopes: [...new Set(b.scopes)] });
        return reply.code(201).send({ ...keyDto(record), key });
      },
    },
    {
      method: 'get',
      path: '/v1/api-keys',
      scope: 'admin',
      tag: 'API keys',
      summary: 'List API keys (metadata only; secrets are never returned).',
      success: [[200, 'All keys']],
      async handler() {
        return { keys: (await listApiKeys(pool)).map(keyDto) };
      },
    },
    {
      method: 'delete',
      path: '/v1/api-keys/:id',
      scope: 'admin',
      tag: 'API keys',
      summary: 'Revoke an API key. Takes effect on the next request.',
      params: idParams,
      success: [[204, 'Revoked']],
      async handler(req, reply) {
        if (!(await revokeApiKey(pool, idOf(req)))) throw notFound('active API key');
        return reply.code(204).send();
      },
    },
  ];
}
