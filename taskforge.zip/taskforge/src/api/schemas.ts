import { z } from 'zod';
import { SCOPES } from '../core/apikeys.js';
import type { ApiKeyRecord } from '../core/apikeys.js';
import type { Job, JobAttempt, Schedule } from '../core/index.js';

// ---- request schemas (single source of truth: validation AND the OpenAPI document) ----

const name = (max: number) => z.string().regex(new RegExp(`^[A-Za-z0-9._:-]{1,${max}}$`), 'letters, digits and . _ : - only');
const uuid = z.uuid();

export const idParams = z.object({ id: uuid });

export const enqueueBody = z
  .object({
    type: name(128).describe('Handler type, e.g. "http.webhook"'),
    payload: z.unknown().optional().describe('Any JSON value passed to the handler'),
    queue: name(64).default('default'),
    priority: z.number().int().min(-100).max(100).default(0).describe('Higher runs first'),
    delayMs: z.number().int().min(0).max(365 * 86_400_000).optional().describe('Run this long from now'),
    runAt: z.iso.datetime({ offset: true }).optional().describe('Run at this time (ISO 8601). Exclusive with delayMs'),
    maxAttempts: z.number().int().min(1).max(100).default(5),
    idempotencyKey: z.string().min(1).max(255).optional().describe('Also accepted as the Idempotency-Key header'),
  })
  .strict()
  .refine((b) => !(b.delayMs !== undefined && b.runAt !== undefined), {
    message: 'delayMs and runAt are mutually exclusive',
    path: ['runAt'],
  });

export const listJobsQuery = z.object({
  status: z.enum(['queued', 'running', 'succeeded', 'dead', 'cancelled']).optional(),
  queue: name(64).optional(),
  type: name(128).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(50),
  cursor: z.string().max(200).optional().describe('nextCursor from the previous page'),
});

export const dlqQuery = listJobsQuery.omit({ status: true });

export const createScheduleBody = z
  .object({
    name: name(100),
    cron: z.string().min(1).max(100).describe('Standard 5-field cron: minute hour day month weekday'),
    timezone: z.string().min(1).max(64).default('UTC').describe('IANA timezone, e.g. America/New_York'),
    type: name(128),
    payload: z.unknown().optional(),
    queue: name(64).default('default'),
    priority: z.number().int().min(-100).max(100).default(0),
    maxAttempts: z.number().int().min(1).max(100).default(5),
  })
  .strict();

export const patchScheduleBody = z.object({ enabled: z.boolean() }).strict();

export const createKeyBody = z
  .object({
    name: z.string().trim().min(1).max(100),
    scopes: z.array(z.enum(SCOPES)).min(1).max(SCOPES.length),
  })
  .strict();

// ---- response mapping ----

const iso = (d: Date | null) => (d ? d.toISOString() : null);

export const jobDto = (j: Job) => ({
  id: j.id,
  queue: j.queue,
  type: j.type,
  payload: j.payload,
  status: j.status,
  priority: j.priority,
  runAt: j.runAt.toISOString(),
  attempts: j.attempts,
  maxAttempts: j.maxAttempts,
  lockedBy: j.lockedBy,
  leaseExpiresAt: iso(j.leaseExpiresAt),
  idempotencyKey: j.idempotencyKey,
  scheduleId: j.scheduleId,
  scheduledFor: iso(j.scheduledFor),
  lastError: j.lastError,
  result: j.result,
  createdAt: j.createdAt.toISOString(),
  updatedAt: j.updatedAt.toISOString(),
  startedAt: iso(j.startedAt),
  finishedAt: iso(j.finishedAt),
});

export const attemptDto = (a: JobAttempt) => ({
  attempt: a.attempt,
  workerId: a.workerId,
  startedAt: a.startedAt.toISOString(),
  finishedAt: iso(a.finishedAt),
  outcome: a.outcome,
  error: a.error,
});

export const scheduleDto = (s: Schedule) => ({
  id: s.id,
  name: s.name,
  cron: s.cronExpr,
  timezone: s.timezone,
  queue: s.queue,
  type: s.type,
  payload: s.payload,
  priority: s.priority,
  maxAttempts: s.maxAttempts,
  enabled: s.enabled,
  nextFireAt: s.nextFireAt.toISOString(),
  lastFiredAt: iso(s.lastFiredAt),
  createdAt: s.createdAt.toISOString(),
});

export const keyDto = (k: ApiKeyRecord) => ({
  id: k.id,
  name: k.name,
  scopes: k.scopes,
  createdAt: k.createdAt.toISOString(),
  lastUsedAt: iso(k.lastUsedAt),
  revokedAt: iso(k.revokedAt),
});

// ---- cursor encoding (opaque to clients) ----

export const encodeCursor = (c: { ts: string; id: string }) => Buffer.from(JSON.stringify(c)).toString('base64url');

const cursorShape = z.object({ ts: z.iso.datetime({ precision: 6 }), id: uuid });

export function decodeCursor(raw: string): { ts: string; id: string } | null {
  try {
    const parsed = cursorShape.safeParse(JSON.parse(Buffer.from(raw, 'base64url').toString('utf8')));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}
