import { createApiKey, SCOPES } from '../core/apikeys.js';
import type { Scope } from '../core/apikeys.js';
import { createPool } from '../db/pool.js';

// Usage: npm run create-key -- <name> [scope,scope,...]   (default scopes: jobs:read,jobs:write)
const [name, scopeArg] = process.argv.slice(2);
const url = process.env.DATABASE_URL;
if (!name || !url) {
  console.error('usage: DATABASE_URL=... npm run create-key -- <name> [scope,scope,...]');
  console.error(`scopes: ${SCOPES.join(', ')}`);
  process.exit(1);
}
const scopes = (scopeArg ? scopeArg.split(',') : ['jobs:read', 'jobs:write']).map((s) => s.trim());
const invalid = scopes.filter((s) => !(SCOPES as readonly string[]).includes(s));
if (invalid.length) {
  console.error(`unknown scope(s): ${invalid.join(', ')}`);
  process.exit(1);
}

const pool = createPool(url, 1);
try {
  const { record, key } = await createApiKey(pool, { name, scopes: scopes as Scope[] });
  console.log(`id:     ${record.id}`);
  console.log(`scopes: ${record.scopes.join(', ')}`);
  console.log(`key:    ${key}`);
  console.log('Store this key now: only its hash is kept, so it cannot be shown again.');
} finally {
  await pool.end();
}
