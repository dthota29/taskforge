import { z } from 'zod';
import type { ZodType } from 'zod';
import type { RouteDef } from './routes.js';

type JsonSchema = Record<string, unknown>;

// io:'input' = describe what clients may send (defaults optional); unrepresentable bits become "any".
const toSchema = (s: ZodType): JsonSchema => {
  const { $schema: _ignored, ...rest } = z.toJSONSchema(s, { io: 'input', unrepresentable: 'any' }) as JsonSchema;
  return rest;
};

const errorResponse = (description: string) => ({
  description,
  content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
});

/** Generate the OpenAPI 3.1 document from the same route table and zod schemas the server runs. */
export function buildOpenApi(routes: RouteDef[], version: string): JsonSchema {
  const paths: Record<string, Record<string, unknown>> = {};

  for (const r of routes) {
    const path = r.path.replace(/:(\w+)/g, '{$1}');
    const parameters: unknown[] = [];
    for (const [where, schema] of [
      ['path', r.params],
      ['query', r.query],
    ] as const) {
      if (!schema) continue;
      const js = toSchema(schema) as { properties?: Record<string, JsonSchema>; required?: string[] };
      for (const [name, prop] of Object.entries(js.properties ?? {})) {
        parameters.push({ name, in: where, required: where === 'path' || !!js.required?.includes(name), schema: prop });
      }
    }

    const responses: Record<string, unknown> = {};
    for (const [status, description] of r.success) {
      responses[String(status)] = { description };
    }
    responses['400'] = errorResponse('Validation error');
    responses['401'] = errorResponse('Missing or invalid API key');
    responses['403'] = errorResponse(`API key lacks the required scope (${r.scope})`);
    if (r.params) responses['404'] = errorResponse('Not found');
    responses['429'] = errorResponse('Rate limited; see Retry-After');

    (paths[path] ??= {})[r.method] = {
      tags: [r.tag],
      summary: r.summary,
      description: `Required scope: \`${r.scope}\` (or \`admin\`).`,
      parameters: parameters.length ? parameters : undefined,
      requestBody: r.body
        ? { required: true, content: { 'application/json': { schema: toSchema(r.body) } } }
        : undefined,
      responses,
      security: [{ bearerAuth: [] }],
    };
  }

  return {
    openapi: '3.1.0',
    info: {
      title: 'TaskForge API',
      version,
      description:
        'Distributed job scheduler. Jobs are delivered at-least-once: handlers must be idempotent. ' +
        'Submit with an idempotency key to make retries of the submit call safe.',
    },
    paths,
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', description: 'API key: `Authorization: Bearer tf_...`' },
      },
      schemas: {
        Error: {
          type: 'object',
          required: ['error'],
          properties: {
            error: {
              type: 'object',
              required: ['code', 'message', 'requestId'],
              properties: {
                code: { type: 'string', examples: ['validation_error', 'unauthorized', 'not_found', 'rate_limited'] },
                message: { type: 'string' },
                requestId: { type: 'string' },
                details: {},
              },
            },
          },
        },
      },
    },
  };
}
