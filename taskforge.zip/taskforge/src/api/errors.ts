/** An error that is safe to show the client: it carries its own status code and stable machine code. */
export class ApiError extends Error {
  constructor(
    readonly statusCode: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
  }
}

export const notFound = (what: string) => new ApiError(404, 'not_found', `${what} not found`);

/** Consistent error body for every failure: { error: { code, message, requestId, details? } } */
export interface ErrorBody {
  error: { code: string; message: string; requestId: string; details?: unknown };
}
