import { setTimeout as sleep } from 'node:timers/promises';
import { ensureBootstrapKey } from '../core/apikeys.js';
import { loadConfig } from '../config.js';
import { migrate } from '../db/migrate.js';
import { createPool } from '../db/pool.js';
import { createLogger } from '../logger.js';
import { createMetrics, registerQueueGauges, startMetricsServer } from '../metrics.js';
import { buildApp } from './app.js';

const cfg = loadConfig();
const logger = createLogger(cfg.LOG_LEVEL, { role: 'api' });
const pool = createPool(cfg.DATABASE_URL, cfg.DB_POOL_MAX);
const metrics = createMetrics();
registerQueueGauges(metrics, pool);

if (cfg.RUN_MIGRATIONS) {
  const r = await migrate(pool); // advisory-locked: safe even if several replicas start together
  logger.info({ applied: r.applied }, 'migrations checked');
}
if (cfg.ADMIN_API_KEY) {
  await ensureBootstrapKey(pool, cfg.ADMIN_API_KEY);
  logger.info('bootstrap admin key is active');
}

const state = { shuttingDown: false };
const app = await buildApp({
  pool,
  logger,
  metrics,
  limits: { ipPerMinute: cfg.IP_RATE_LIMIT_PER_MINUTE, keyPerMinute: cfg.KEY_RATE_LIMIT_PER_MINUTE },
  trustProxy: cfg.TRUST_PROXY,
  state,
});
const metricsServer = startMetricsServer(metrics.registry, cfg.METRICS_PORT, logger);
await app.listen({ port: cfg.PORT, host: '0.0.0.0' });

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'shutting down');
  setTimeout(() => process.exit(1), (cfg.SHUTDOWN_DELAY_SECONDS + 20) * 1000).unref();
  // 1. Fail readiness so the load balancer stops routing here. 2. Keep serving while it notices.
  // 3. Close: finishes in-flight requests, then connections drain.
  state.shuttingDown = true;
  await sleep(cfg.SHUTDOWN_DELAY_SECONDS * 1000);
  await app.close();
  metricsServer.close();
  await pool.end();
  logger.info('shutdown complete');
  process.exit(0);
}
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('unhandledRejection', (err) => {
  logger.fatal({ err }, 'unhandled rejection');
  process.exit(1);
});
