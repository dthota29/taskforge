import { CronExpressionParser } from 'cron-parser';
import type { Pool } from '../db/pool.js';

export interface Schedule {
  id: string;
  name: string;
  cronExpr: string;
  timezone: string;
  queue: string;
  type: string;
  payload: unknown;
  priority: number;
  maxAttempts: number;
  enabled: boolean;
  nextFireAt: Date;
  lastFiredAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateScheduleInput {
  name: string;
  cron: string;
  timezone?: string;
  type: string;
  payload?: unknown;
  queue?: string;
  priority?: number;
  maxAttempts?: number;
}

export class InvalidScheduleError extends Error {}
export class ScheduleConflictError extends Error {}

export interface ScheduleRow {
  id: string;
  name: string;
  cron_expr: string;
  timezone: string;
  queue: string;
  type: string;
  payload: unknown;
  priority: number;
  max_attempts: number;
  enabled: boolean;
  next_fire_at: Date;
  last_fired_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

export function mapSchedule(r: ScheduleRow): Schedule {
  return {
    id: r.id,
    name: r.name,
    cronExpr: r.cron_expr,
    timezone: r.timezone,
    queue: r.queue,
    type: r.type,
    payload: r.payload,
    priority: r.priority,
    maxAttempts: r.max_attempts,
    enabled: r.enabled,
    nextFireAt: r.next_fire_at,
    lastFiredAt: r.last_fired_at,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

/** Next fire time strictly after `after`, evaluated in the schedule's timezone (DST-aware). */
export function nextFireAfter(cronExpr: string, timezone: string, after: Date): Date {
  return CronExpressionParser.parse(cronExpr, { currentDate: after, tz: timezone }).next().toDate();
}

/** Reject anything we cannot schedule safely. Standard 5-field cron only (no per-second schedules). */
export function validateSchedule(cronExpr: string, timezone: string): void {
  if (cronExpr.trim().split(/\s+/).length !== 5) {
    throw new InvalidScheduleError('cron expression must have exactly 5 fields (minute hour day month weekday)');
  }
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: timezone });
  } catch {
    throw new InvalidScheduleError(`unknown timezone "${timezone}"`);
  }
  try {
    nextFireAfter(cronExpr, timezone, new Date());
  } catch (err) {
    throw new InvalidScheduleError(`invalid cron expression: ${(err as Error).message}`);
  }
}

export async function createSchedule(pool: Pool, input: CreateScheduleInput): Promise<Schedule> {
  const timezone = input.timezone ?? 'UTC';
  validateSchedule(input.cron, timezone);
  const next = nextFireAfter(input.cron, timezone, new Date());
  try {
    const { rows } = await pool.query<ScheduleRow>(
      `INSERT INTO schedules (name, cron_expr, timezone, queue, type, payload, priority, max_attempts, next_fire_at)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $8, $9)
       RETURNING *`,
      [
        input.name,
        input.cron.trim(),
        timezone,
        input.queue ?? 'default',
        input.type,
        JSON.stringify(input.payload ?? {}),
        input.priority ?? 0,
        input.maxAttempts ?? 5,
        next,
      ],
    );
    return mapSchedule(rows[0]!);
  } catch (err) {
    if ((err as { code?: string }).code === '23505') {
      throw new ScheduleConflictError(`a schedule named "${input.name}" already exists`);
    }
    throw err;
  }
}

export async function listSchedules(pool: Pool): Promise<Schedule[]> {
  const { rows } = await pool.query<ScheduleRow>('SELECT * FROM schedules ORDER BY name');
  return rows.map(mapSchedule);
}

export async function getSchedule(pool: Pool, id: string): Promise<Schedule | null> {
  const { rows } = await pool.query<ScheduleRow>('SELECT * FROM schedules WHERE id = $1', [id]);
  return rows[0] ? mapSchedule(rows[0]) : null;
}

/** Enabling recomputes the next fire time so a long-paused schedule does not fire a stale backlog. */
export async function setScheduleEnabled(pool: Pool, id: string, enabled: boolean): Promise<Schedule | null> {
  const current = await getSchedule(pool, id);
  if (!current) return null;
  const next = enabled ? nextFireAfter(current.cronExpr, current.timezone, new Date()) : current.nextFireAt;
  const { rows } = await pool.query<ScheduleRow>(
    'UPDATE schedules SET enabled = $2, next_fire_at = $3 WHERE id = $1 RETURNING *',
    [id, enabled, next],
  );
  return rows[0] ? mapSchedule(rows[0]) : null;
}

export async function deleteSchedule(pool: Pool, id: string): Promise<boolean> {
  const res = await pool.query('DELETE FROM schedules WHERE id = $1', [id]);
  return res.rowCount === 1;
}
