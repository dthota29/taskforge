import type { Pool, Queryable } from '../db/pool.js';
import { withTransaction } from '../db/pool.js';
import { backoffDelayMs, DEFAULT_BACKOFF } from './backoff.js';
import type { BackoffOptions } from './backoff.js';
import type {
  CancelOutcome,
  ClaimOptions,
  EnqueueInput,
  EnqueueResult,
  FailOutcome,
  Job,
  JobStatus,
} from './types.js';

interface JobRow {
  id: string;
  queue: string;
  type: string;
  payload: unknown;
  status: JobStatus;
  priority: number;
  run_at: Date;
  attempts: number;
  max_attempts: number;
  locked_by: string | null;
  lease_expires_at: Date | null;
  fence: string; // bigint arrives as string
  idempotency_key: string | null;
  schedule_id: string | null;
  scheduled_for: Date | null;
  last_error: string | null;
  result: unknown;
  created_at: Date;
  updated_at: Date;
  started_at: Date | null;
  finished_at: Date | null;
}

const MAX_ERROR_LENGTH = 4_000;

export function mapJob(r: JobRow): Job {
  return {
    id: r.id,
    queue: r.queue,
    type: r.type,
    payload: r.payload,
    status: r.status,
    priority: r.priority,
    runAt: r.run_at,
    attempts: r.attempts,
    maxAttempts: r.max_attempts,
    lockedBy: r.locked_by,
    leaseExpiresAt: r.lease_expires_at,
    fence: Number(r.fence),
    idempotencyKey: r.idempotency_key,
    scheduleId: r.schedule_id,
    scheduledFor: r.scheduled_for,
    lastError: r.last_error,
    result: r.result,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
  };
}

const truncate = (s: string) => (s.length > MAX_ERROR_LENGTH ? s.slice(0, MAX_ERROR_LENGTH) : s);

/**
 * Insert a job. With an idempotencyKey, a duplicate (same queue + key) returns the
 * existing job with created=false. Uniqueness is enforced by a database index, so this is
 * safe under concurrent submits: ON CONFLICT DO NOTHING waits for any in-flight twin.
 */
export async function enqueue(pool: Queryable, input: EnqueueInput): Promise<EnqueueResult> {
  const queue = input.queue ?? 'default';
  const params = [
    queue,
    input.type,
    JSON.stringify(input.payload ?? {}),
    input.priority ?? 0,
    input.runAt ?? null,
    input.delayMs ?? 0,
    input.maxAttempts ?? 5,
    input.idempotencyKey ?? null,
    input.scheduleId ?? null,
    input.scheduledFor ?? null,
  ];
  const inserted = await pool.query<JobRow>(
    `INSERT INTO jobs (queue, type, payload, priority, run_at, max_attempts, idempotency_key, schedule_id, scheduled_for)
     VALUES ($1, $2, $3::jsonb, $4,
             COALESCE($5::timestamptz, now() + make_interval(secs => $6::double precision / 1000)),
             $7, $8, $9, $10)
     ON CONFLICT DO NOTHING
     RETURNING *`,
    params,
  );
  const row = inserted.rows[0];
  if (row) return { job: mapJob(row), created: true };

  // Conflict on the idempotency index or the (schedule, fire time) index: return the existing job.
  const existing = await pool.query<JobRow>(
    input.idempotencyKey != null
      ? 'SELECT * FROM jobs WHERE queue = $1 AND idempotency_key = $2'
      : 'SELECT * FROM jobs WHERE schedule_id = $1 AND scheduled_for = $2',
    input.idempotencyKey != null ? [queue, input.idempotencyKey] : [input.scheduleId, input.scheduledFor],
  );
  const found = existing.rows[0];
  if (!found) throw new Error('enqueue conflict but existing job not found');
  return { job: mapJob(found), created: false };
}

/**
 * Atomically claim up to `limit` runnable jobs for a worker.
 *
 * One statement does everything, so there is no window between "pick" and "mark":
 *  - FOR UPDATE SKIP LOCKED lets concurrent workers pass over rows another worker is claiming
 *    instead of blocking, so no two workers can ever receive the same job.
 *  - fence is incremented, which invalidates any previous holder of the job.
 *  - the lease deadline is computed with the database clock, so worker clock skew is irrelevant.
 *  - an attempt row is recorded for audit.
 */
export async function claim(pool: Pool, opts: ClaimOptions): Promise<Job[]> {
  const queues = opts.queues?.length ? opts.queues : ['default'];

  // The candidate lookup MUST walk jobs_claim_idx in order and stop at LIMIT, taking row locks as it
  // goes. `queue = ANY(array)` defeats that (the planner cannot return rows ordered across several
  // queue values), and it degraded to a full scan + sort of the backlog on every claim (~40 ms at 20k
  // queued jobs). So: plain equality for one queue (the common case), and a per-queue LATERAL lookup
  // for several, each walking the index with its own SKIP LOCKED. The benchmark asserts the plan.
  const next =
    queues.length === 1
      ? `SELECT id FROM jobs
         WHERE status = 'queued' AND queue = $1 AND run_at <= now()
         ORDER BY priority DESC, run_at ASC, id ASC
         LIMIT $2
         FOR UPDATE SKIP LOCKED`
      : `SELECT id FROM (
           SELECT c.id, c.priority, c.run_at
           FROM unnest($1::text[]) AS q(queue)
           CROSS JOIN LATERAL (
             SELECT id, priority, run_at FROM jobs
             WHERE status = 'queued' AND queue = q.queue AND run_at <= now()
             ORDER BY priority DESC, run_at ASC, id ASC
             LIMIT $2
             FOR UPDATE SKIP LOCKED
           ) c
         ) cand
         ORDER BY priority DESC, run_at ASC, id ASC
         LIMIT $2`;

  const { rows } = await pool.query<JobRow>(
    `WITH next AS (
       ${next}
     ),
     claimed AS (
       UPDATE jobs j SET
         status = 'running',
         locked_by = $3,
         lease_expires_at = now() + make_interval(secs => $4::double precision),
         fence = j.fence + 1,
         attempts = j.attempts + 1,
         started_at = now()
       FROM next WHERE j.id = next.id
       RETURNING j.*
     ),
     audit AS (
       INSERT INTO job_attempts (job_id, attempt, fence, worker_id)
       SELECT id, attempts, fence, locked_by FROM claimed
     )
     SELECT * FROM claimed`,
    [queues.length === 1 ? queues[0] : queues, opts.limit ?? 1, opts.workerId, opts.leaseSeconds],
  );
  return rows.map(mapJob).sort((a, b) => b.priority - a.priority || a.runAt.getTime() - b.runAt.getTime());
}

/**
 * Extend the lease. Returns false if the caller no longer owns the job (stale fence):
 * the worker must stop working on it immediately.
 */
export async function heartbeat(
  pool: Pool,
  jobId: string,
  fence: number,
  leaseSeconds: number,
): Promise<boolean> {
  const res = await pool.query(
    `UPDATE jobs SET lease_expires_at = now() + make_interval(secs => $3::double precision)
     WHERE id = $1 AND fence = $2 AND status = 'running'`,
    [jobId, fence, leaseSeconds],
  );
  return res.rowCount === 1;
}

/** Mark a job succeeded. Returns false (and changes nothing) if the fence is stale. */
export async function complete(pool: Pool, jobId: string, fence: number, result?: unknown): Promise<boolean> {
  const res = await pool.query(
    `WITH done AS (
       UPDATE jobs SET
         status = 'succeeded', finished_at = now(), locked_by = NULL, lease_expires_at = NULL,
         result = $3::jsonb, last_error = NULL
       WHERE id = $1 AND fence = $2 AND status = 'running'
       RETURNING id, attempts, fence
     ),
     audit AS (
       UPDATE job_attempts a SET finished_at = now(), outcome = 'succeeded'
       FROM done WHERE a.job_id = done.id AND a.attempt = done.attempts AND a.fence = done.fence
     )
     SELECT 1 FROM done`,
    [jobId, fence, result === undefined ? null : JSON.stringify(result)],
  );
  return res.rowCount === 1;
}

/**
 * Record a failed attempt. Schedules a retry with exponential backoff, or moves the job to the
 * dead-letter queue (status 'dead') when attempts are exhausted or the error is non-retryable.
 * The row lock plus fence check make this safe against a concurrent reaper or stale worker.
 */
export async function fail(
  pool: Pool,
  jobId: string,
  fence: number,
  error: string,
  opts: { retryable?: boolean; backoff?: BackoffOptions } = {},
): Promise<FailOutcome> {
  const message = truncate(error);
  return withTransaction(pool, async (c) => {
    const cur = await c.query<{ attempts: number; max_attempts: number }>(
      `SELECT attempts, max_attempts FROM jobs
       WHERE id = $1 AND fence = $2 AND status = 'running' FOR UPDATE`,
      [jobId, fence],
    );
    const row = cur.rows[0];
    if (!row) return { outcome: 'stale' } as const;

    const dead = opts.retryable === false || row.attempts >= row.max_attempts;
    const delayMs = dead ? 0 : backoffDelayMs(row.attempts, opts.backoff ?? DEFAULT_BACKOFF);
    const updated = await c.query<{ run_at: Date }>(
      `UPDATE jobs SET
         status = $3,
         run_at = CASE WHEN $3 = 'queued' THEN now() + make_interval(secs => $4::double precision / 1000) ELSE run_at END,
         finished_at = CASE WHEN $3 = 'dead' THEN now() ELSE NULL END,
         locked_by = NULL, lease_expires_at = NULL, last_error = $5
       WHERE id = $1 AND fence = $2
       RETURNING run_at`,
      [jobId, fence, dead ? 'dead' : 'queued', delayMs, message],
    );
    await c.query(
      `UPDATE job_attempts SET finished_at = now(), outcome = 'failed', error = $4
       WHERE job_id = $1 AND attempt = $2 AND fence = $3`,
      [jobId, row.attempts, fence, message],
    );
    if (dead) return { outcome: 'dead' } as const;
    const retryAt = updated.rows[0]?.run_at;
    if (!retryAt) throw new Error('fail: update returned no row');
    return { outcome: 'retry', retryAt } as const;
  });
}

/**
 * Hand a running job straight back to the queue (graceful shutdown). The interrupted attempt is
 * not counted against max_attempts because it did not fail on its own merits.
 * Returns false if the caller no longer owns the job.
 */
export async function release(pool: Pool, jobId: string, fence: number): Promise<boolean> {
  const res = await pool.query(
    `WITH released AS (
       UPDATE jobs SET status = 'queued', run_at = now(), attempts = attempts - 1,
         locked_by = NULL, lease_expires_at = NULL
       WHERE id = $1 AND fence = $2 AND status = 'running'
       RETURNING id, attempts, fence
     ),
     audit AS (
       UPDATE job_attempts a SET finished_at = now(), outcome = 'released'
       FROM released WHERE a.job_id = released.id AND a.attempt = released.attempts + 1 AND a.fence = released.fence
     )
     SELECT 1 FROM released`,
    [jobId, fence],
  );
  return res.rowCount === 1;
}

export async function getJob(pool: Pool, jobId: string): Promise<Job | null> {
  const { rows } = await pool.query<JobRow>('SELECT * FROM jobs WHERE id = $1', [jobId]);
  const row = rows[0];
  return row ? mapJob(row) : null;
}

export interface ListJobsOptions {
  status?: JobStatus;
  queue?: string;
  type?: string;
  limit: number;
  /** Opaque position from a previous page (see nextCursor). */
  after?: { ts: string; id: string };
}

export interface JobPage {
  jobs: Job[];
  nextCursor: { ts: string; id: string } | null;
}

/**
 * Newest-first listing with keyset pagination. Offset pagination would rescan skipped rows and
 * shift under concurrent inserts; a (created_at, id) cursor does neither. The cursor timestamp is
 * formatted by Postgres so microsecond precision survives the round trip (a JS Date would truncate
 * to milliseconds and could skip or repeat rows).
 */
export async function listJobs(pool: Pool, o: ListJobsOptions): Promise<JobPage> {
  const where: string[] = [];
  const params: unknown[] = [];
  const add = (sql: string, ...values: unknown[]) => {
    let s = sql;
    for (const v of values) {
      params.push(v);
      s = s.replace('?', `$${params.length}`);
    }
    where.push(s);
  };
  if (o.status) add('status = ?', o.status);
  if (o.queue) add('queue = ?', o.queue);
  if (o.type) add('type = ?', o.type);
  if (o.after) add('(created_at, id) < (?::timestamptz, ?::uuid)', o.after.ts, o.after.id);
  params.push(o.limit + 1);

  const { rows } = await pool.query<JobRow & { cursor_ts: string }>(
    `SELECT *, to_char(created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_ts
     FROM jobs
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY created_at DESC, id DESC
     LIMIT $${params.length}`,
    params,
  );
  const page = rows.slice(0, o.limit);
  const last = page[page.length - 1];
  return {
    jobs: page.map(mapJob),
    nextCursor: rows.length > o.limit && last ? { ts: last.cursor_ts, id: last.id } : null,
  };
}

export interface JobAttempt {
  attempt: number;
  fence: number;
  workerId: string;
  startedAt: Date;
  finishedAt: Date | null;
  outcome: string | null;
  error: string | null;
}

export async function listAttempts(pool: Pool, jobId: string): Promise<JobAttempt[]> {
  const { rows } = await pool.query<{
    attempt: number;
    fence: string;
    worker_id: string;
    started_at: Date;
    finished_at: Date | null;
    outcome: string | null;
    error: string | null;
  }>('SELECT * FROM job_attempts WHERE job_id = $1 ORDER BY attempt, fence', [jobId]);
  return rows.map((r) => ({
    attempt: r.attempt,
    fence: Number(r.fence),
    workerId: r.worker_id,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    outcome: r.outcome,
    error: r.error,
  }));
}

/** Only queued jobs can be cancelled; a running job has a worker mid-flight. */
export async function cancel(pool: Pool, jobId: string): Promise<CancelOutcome> {
  const res = await pool.query(
    `UPDATE jobs SET status = 'cancelled', finished_at = now()
     WHERE id = $1 AND status = 'queued'`,
    [jobId],
  );
  if (res.rowCount === 1) return 'cancelled';
  const exists = await pool.query('SELECT 1 FROM jobs WHERE id = $1', [jobId]);
  return exists.rowCount === 1 ? 'not_cancellable' : 'not_found';
}

/** Move a dead-lettered job back to the queue with a fresh attempt budget. */
export async function replay(pool: Pool, jobId: string): Promise<Job | null> {
  const { rows } = await pool.query<JobRow>(
    `UPDATE jobs SET status = 'queued', attempts = 0, run_at = now(), finished_at = NULL
     WHERE id = $1 AND status = 'dead'
     RETURNING *`,
    [jobId],
  );
  const row = rows[0];
  return row ? mapJob(row) : null;
}
