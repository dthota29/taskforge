import type { Pool } from '../db/pool.js';

export interface RetentionOptions {
  /** Days to keep succeeded/cancelled jobs. */
  finishedDays: number;
  /** Days to keep dead-lettered jobs (kept longer: someone may want to inspect and replay them). */
  deadDays: number;
  batchSize?: number;
  /** Safety cap on batches per call so one run cannot monopolise the database. */
  maxBatches?: number;
}

/**
 * Delete old terminal jobs in small batches (short transactions, no long table locks).
 * job_attempts rows go with them via ON DELETE CASCADE. Returns the number of jobs deleted.
 */
export async function pruneFinishedJobs(pool: Pool, opts: RetentionOptions): Promise<number> {
  const batch = opts.batchSize ?? 1000;
  const maxBatches = opts.maxBatches ?? 20;
  let total = 0;
  for (let i = 0; i < maxBatches; i++) {
    const res = await pool.query(
      `DELETE FROM jobs WHERE id IN (
         SELECT id FROM jobs
         WHERE (status IN ('succeeded','cancelled') AND finished_at < now() - make_interval(days => $1))
            OR (status = 'dead' AND finished_at < now() - make_interval(days => $2))
         LIMIT $3
         FOR UPDATE SKIP LOCKED
       )`,
      [opts.finishedDays, opts.deadDays, batch],
    );
    total += res.rowCount ?? 0;
    if ((res.rowCount ?? 0) < batch) break;
  }
  return total;
}
