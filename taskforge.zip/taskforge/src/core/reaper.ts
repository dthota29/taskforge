import type { Pool } from '../db/pool.js';
import type { ReapResult } from './types.js';

/**
 * Recover jobs whose worker vanished (crash, OOM kill, network partition).
 *
 * A running job whose lease expired is requeued, or dead-lettered if it has used all its
 * attempts. The attempt was already counted at claim time, so a job that keeps killing its
 * worker ("poison pill") cannot loop forever. The fence is NOT bumped here: the next claim
 * bumps it, which is what rejects a zombie worker that wakes up and tries to ack late.
 *
 * SKIP LOCKED lets several reapers (one per pod) run concurrently without contending.
 */
export async function reapExpiredLeases(pool: Pool, batchSize = 100): Promise<ReapResult> {
  const { rows } = await pool.query<{ status: 'queued' | 'dead'; n: string }>(
    `WITH expired AS (
       SELECT id FROM jobs
       WHERE status = 'running' AND lease_expires_at < now()
       ORDER BY lease_expires_at
       LIMIT $1
       FOR UPDATE SKIP LOCKED
     ),
     reaped AS (
       UPDATE jobs j SET
         status = CASE WHEN j.attempts >= j.max_attempts THEN 'dead' ELSE 'queued' END,
         run_at = CASE WHEN j.attempts >= j.max_attempts THEN j.run_at ELSE now() END,
         finished_at = CASE WHEN j.attempts >= j.max_attempts THEN now() ELSE NULL END,
         locked_by = NULL,
         lease_expires_at = NULL,
         last_error = 'lease expired: worker presumed dead'
       FROM expired WHERE j.id = expired.id
       RETURNING j.id, j.attempts, j.fence, j.status
     ),
     audit AS (
       UPDATE job_attempts a SET finished_at = now(), outcome = 'lease_expired',
         error = 'lease expired: worker presumed dead'
       FROM reaped WHERE a.job_id = reaped.id AND a.attempt = reaped.attempts AND a.fence = reaped.fence
     )
     SELECT status, count(*)::text AS n FROM reaped GROUP BY status`,
    [batchSize],
  );
  const result: ReapResult = { requeued: 0, dead: 0 };
  for (const r of rows) {
    if (r.status === 'queued') result.requeued = Number(r.n);
    else result.dead = Number(r.n);
  }
  return result;
}
