export type JobStatus = 'queued' | 'running' | 'succeeded' | 'dead' | 'cancelled';

export interface Job {
  id: string;
  queue: string;
  type: string;
  payload: unknown;
  status: JobStatus;
  priority: number;
  runAt: Date;
  attempts: number;
  maxAttempts: number;
  lockedBy: string | null;
  leaseExpiresAt: Date | null;
  /** Fencing token: incremented on every claim. Acks must present the token they were issued. */
  fence: number;
  idempotencyKey: string | null;
  scheduleId: string | null;
  scheduledFor: Date | null;
  lastError: string | null;
  result: unknown;
  createdAt: Date;
  updatedAt: Date;
  startedAt: Date | null;
  finishedAt: Date | null;
}

export interface EnqueueInput {
  type: string;
  payload?: unknown;
  queue?: string;
  /** Higher runs first. Range -100..100. */
  priority?: number;
  /** Absolute time to run at. Takes precedence over delayMs. */
  runAt?: Date;
  /** Run this many ms from now (database clock). */
  delayMs?: number;
  maxAttempts?: number;
  idempotencyKey?: string;
  /** Set by the cron scheduler. */
  scheduleId?: string;
  scheduledFor?: Date;
}

export interface EnqueueResult {
  job: Job;
  /** false when an existing job with the same (queue, idempotencyKey) was returned instead. */
  created: boolean;
}

export interface ClaimOptions {
  workerId: string;
  queues?: string[];
  leaseSeconds: number;
  limit?: number;
}

export type FailOutcome =
  | { outcome: 'retry'; retryAt: Date }
  | { outcome: 'dead' }
  /** The caller no longer owns the job (lease expired and it was reclaimed or reaped). */
  | { outcome: 'stale' };

export type CancelOutcome = 'cancelled' | 'not_cancellable' | 'not_found';

export interface ReapResult {
  requeued: number;
  dead: number;
}
