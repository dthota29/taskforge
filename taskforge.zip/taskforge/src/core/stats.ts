import type { Pool } from '../db/pool.js';

export interface QueueStats {
  queue: string;
  /** Waiting, including jobs scheduled for the future or backing off before a retry. */
  queued: number;
  /** Queued and due now: this is the real backlog. */
  ready: number;
  running: number;
  /** How long the oldest ready job has been waiting. The key health signal: it grows when workers fall behind. */
  oldestReadyAgeSeconds: number;
}

export interface Stats {
  queues: QueueStats[];
  dead: number;
}

/**
 * Only non-terminal rows are scanned (the partial indexes cover them), so the cost tracks the
 * live backlog rather than the size of the job history.
 */
export async function getStats(pool: Pool): Promise<Stats> {
  const [queues, dead] = await Promise.all([
    pool.query<{ queue: string; queued: number; ready: number; running: number; age: number }>(
      `SELECT queue,
              count(*) FILTER (WHERE status = 'queued')::int AS queued,
              count(*) FILTER (WHERE status = 'queued' AND run_at <= now())::int AS ready,
              count(*) FILTER (WHERE status = 'running')::int AS running,
              COALESCE(EXTRACT(EPOCH FROM now() - min(run_at) FILTER (WHERE status = 'queued' AND run_at <= now())), 0)::float8 AS age
       FROM jobs WHERE status IN ('queued', 'running')
       GROUP BY queue ORDER BY queue`,
    ),
    pool.query<{ n: number }>("SELECT count(*)::int AS n FROM jobs WHERE status = 'dead'"),
  ]);
  return {
    queues: queues.rows.map((r) => ({
      queue: r.queue,
      queued: r.queued,
      ready: r.ready,
      running: r.running,
      oldestReadyAgeSeconds: r.age,
    })),
    dead: dead.rows[0]?.n ?? 0,
  };
}
