import { createHash, randomBytes } from 'node:crypto';
import type { Pool } from '../db/pool.js';

export const SCOPES = ['jobs:read', 'jobs:write', 'schedules:read', 'schedules:write', 'admin'] as const;
export type Scope = (typeof SCOPES)[number];

/** Format check done before touching the database, so garbage tokens cost nothing. */
export const API_KEY_PATTERN = /^tf_[A-Za-z0-9_-]{32,128}$/;

export interface ApiKeyRecord {
  id: string;
  name: string;
  scopes: Scope[];
  createdAt: Date;
  lastUsedAt: Date | null;
  revokedAt: Date | null;
}

interface ApiKeyRow {
  id: string;
  name: string;
  scopes: Scope[];
  created_at: Date;
  last_used_at: Date | null;
  revoked_at: Date | null;
}

const map = (r: ApiKeyRow): ApiKeyRecord => ({
  id: r.id,
  name: r.name,
  scopes: r.scopes,
  createdAt: r.created_at,
  lastUsedAt: r.last_used_at,
  revokedAt: r.revoked_at,
});

export const generateApiKey = (): string => `tf_${randomBytes(32).toString('base64url')}`;

/**
 * Plain SHA-256 is appropriate here: the key is 256 bits of randomness, so there is nothing to
 * brute-force and a slow password hash (bcrypt/argon2) would only add latency to every request.
 * A leaked database therefore does not leak usable keys.
 */
export const hashApiKey = (key: string): string => createHash('sha256').update(key).digest('hex');

/** Returns the stored record and the raw key. The raw key is never stored and cannot be recovered. */
export async function createApiKey(
  pool: Pool,
  input: { name: string; scopes: Scope[] },
): Promise<{ record: ApiKeyRecord; key: string }> {
  const key = generateApiKey();
  const { rows } = await pool.query<ApiKeyRow>(
    'INSERT INTO api_keys (name, key_hash, scopes) VALUES ($1, $2, $3) RETURNING id, name, scopes, created_at, last_used_at, revoked_at',
    [input.name, hashApiKey(key), input.scopes],
  );
  return { record: map(rows[0]!), key };
}

/** Resolve a presented key to its record, or null if unknown or revoked. */
export async function findApiKey(pool: Pool, rawKey: string): Promise<ApiKeyRecord | null> {
  const { rows } = await pool.query<ApiKeyRow>(
    `SELECT id, name, scopes, created_at, last_used_at, revoked_at
     FROM api_keys WHERE key_hash = $1 AND revoked_at IS NULL`,
    [hashApiKey(rawKey)],
  );
  return rows[0] ? map(rows[0]) : null;
}

export async function listApiKeys(pool: Pool): Promise<ApiKeyRecord[]> {
  const { rows } = await pool.query<ApiKeyRow>(
    'SELECT id, name, scopes, created_at, last_used_at, revoked_at FROM api_keys ORDER BY created_at DESC',
  );
  return rows.map(map);
}

export async function revokeApiKey(pool: Pool, id: string): Promise<boolean> {
  const res = await pool.query('UPDATE api_keys SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL', [id]);
  return res.rowCount === 1;
}

export async function touchApiKey(pool: Pool, id: string): Promise<void> {
  await pool.query('UPDATE api_keys SET last_used_at = now() WHERE id = $1', [id]);
}

/**
 * Make the key supplied through the environment (a Kubernetes secret) a valid admin key.
 * The environment is the source of truth: removing it from the secret and restarting is how it
 * is retired, and a previously revoked key is revived if it is configured again.
 */
export async function ensureBootstrapKey(pool: Pool, rawKey: string): Promise<void> {
  await pool.query(
    `INSERT INTO api_keys (name, key_hash, scopes) VALUES ('bootstrap-admin', $1, ARRAY['admin'])
     ON CONFLICT (key_hash) DO UPDATE SET revoked_at = NULL, scopes = ARRAY['admin']`,
    [hashApiKey(rawKey)],
  );
}
