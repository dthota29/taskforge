import type { Logger } from '../logger.js';

export interface LoopHandle {
  stop(): Promise<void>;
}

/**
 * Run fn repeatedly every ~intervalMs (+/-10% jitter so replicas do not synchronise).
 * Errors are logged and never kill the loop. stop() wakes it immediately and waits for the
 * in-progress iteration to finish.
 */
export function runLoop(name: string, intervalMs: number, fn: () => Promise<void>, logger: Logger): LoopHandle {
  let running = true;
  let wake: (() => void) | null = null;

  const sleep = (ms: number) =>
    new Promise<void>((resolve) => {
      const t = setTimeout(done, ms);
      function done() {
        clearTimeout(t);
        wake = null;
        resolve();
      }
      wake = done;
    });

  const done = (async () => {
    while (running) {
      try {
        await fn();
      } catch (err) {
        logger.error({ err, loop: name }, 'loop iteration failed');
      }
      if (running) await sleep(intervalMs * (0.9 + Math.random() * 0.2));
    }
  })();

  return {
    async stop() {
      running = false;
      wake?.();
      await done;
    },
  };
}
