export interface BackoffOptions {
  baseMs: number;
  factor: number;
  maxMs: number;
}

export const DEFAULT_BACKOFF: BackoffOptions = { baseMs: 1_000, factor: 2, maxMs: 3_600_000 };

/**
 * Delay before retrying after the given (1-based) failed attempt.
 * Exponential growth capped at maxMs, with "equal jitter": half fixed, half random.
 * Jitter prevents a burst of failures from retrying in lockstep (thundering herd),
 * while the fixed half guarantees a minimum spacing.
 */
export function backoffDelayMs(
  attempt: number,
  opts: BackoffOptions = DEFAULT_BACKOFF,
  rand: () => number = Math.random,
): number {
  const n = Math.max(1, attempt);
  const exp = Math.min(opts.maxMs, opts.baseMs * Math.pow(opts.factor, n - 1));
  return Math.round(exp / 2 + rand() * (exp / 2));
}
