import pg from 'pg';

export type Pool = pg.Pool;
/** Anything that can run a query: a Pool or a PoolClient inside a transaction. */
export type Queryable = Pick<pg.Pool, 'query'>;

export function createPool(databaseUrl: string, max = 10): Pool {
  const pool = new pg.Pool({
    connectionString: databaseUrl,
    max,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    // Guard rails: a runaway query must not hold locks or connections forever.
    statement_timeout: 15_000,
    idle_in_transaction_session_timeout: 30_000,
    application_name: 'taskforge',
  });
  // Without this handler an idle-client error (e.g. DB restart) crashes the process.
  pool.on('error', (err) => {
    console.error('idle pg client error', err.message);
  });
  return pool;
}

/** Run fn inside a transaction; commit on success, roll back on any throw. */
export async function withTransaction<T>(pool: Pool, fn: (client: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}
