import type { Logger } from '../logger.js';

export interface JobContext {
  jobId: string;
  attempt: number;
  /**
   * Aborted when the job must stop: handler timeout, lease lost (another worker may own the job
   * now), or worker shutdown. Handlers should pass it to fetch/db calls and stop promptly.
   */
  signal: AbortSignal;
  logger: Logger;
}

export type Handler = (payload: unknown, ctx: JobContext) => Promise<unknown>;

export interface HandlerDef {
  handle: Handler;
  /** Hard time limit for one attempt. Defaults to the registry default. */
  timeoutMs?: number;
}

/** Throw from a handler when retrying cannot help (bad input, 4xx): the job goes straight to the DLQ. */
export class NonRetryableError extends Error {
  override name = 'NonRetryableError';
}

export class HandlerRegistry {
  private readonly handlers = new Map<string, HandlerDef>();

  register(type: string, handler: Handler | HandlerDef): this {
    this.handlers.set(type, typeof handler === 'function' ? { handle: handler } : handler);
    return this;
  }

  get(type: string): HandlerDef | undefined {
    return this.handlers.get(type);
  }

  types(): string[] {
    return [...this.handlers.keys()].sort();
  }
}
