import type { BackoffOptions } from '../core/backoff.js';
import { claim, complete, fail, heartbeat, release } from '../core/jobs.js';
import type { FailOutcome, Job } from '../core/types.js';
import type { Pool } from '../db/pool.js';
import type { Logger } from '../logger.js';
import type { JobOutcome, WorkerMetrics } from '../metrics.js';
import { NonRetryableError } from './registry.js';
import type { HandlerRegistry } from './registry.js';

export interface WorkerOptions {
  workerId: string;
  queues: string[];
  concurrency: number;
  leaseSeconds: number;
  heartbeatSeconds: number;
  pollIntervalMs: number;
  /** How long stop() waits for in-flight jobs before aborting and releasing them. */
  drainTimeoutMs: number;
  /** Extra time after aborting for handlers to unwind before leases are force-released. */
  abortGraceMs?: number;
  defaultHandlerTimeoutMs?: number;
  backoff?: BackoffOptions;
  metrics?: WorkerMetrics;
}

type AbortReason = 'lease_lost' | 'shutdown' | 'timeout';

interface Execution {
  job: Job;
  abort: AbortController;
  reason: AbortReason | null;
  promise: Promise<void>;
}

const DEFAULT_HANDLER_TIMEOUT_MS = 5 * 60_000;
const errorMessage = (err: unknown) => (err instanceof Error ? `${err.name}: ${err.message}` : String(err));

/**
 * Pulls jobs from the database and runs them with bounded concurrency.
 *
 * Delivery is at-least-once: if a worker dies after finishing a job but before acking, the lease
 * expires and the job runs again. Handlers must therefore be idempotent (the webhook handler sends
 * an Idempotency-Key header for exactly this reason).
 */
export class Worker {
  private readonly inflight = new Map<string, Execution>();
  private stopping = false;
  private loopDone: Promise<void> | null = null;
  private wake: (() => void) | null = null;

  constructor(
    private readonly pool: Pool,
    private readonly registry: HandlerRegistry,
    private readonly opts: WorkerOptions,
    private readonly logger: Logger,
  ) {}

  get inflightCount(): number {
    return this.inflight.size;
  }

  start(): void {
    if (this.loopDone) throw new Error('worker already started');
    this.logger.info(
      { workerId: this.opts.workerId, queues: this.opts.queues, concurrency: this.opts.concurrency },
      'worker started',
    );
    this.loopDone = this.loop();
  }

  /**
   * Graceful shutdown: stop claiming, let in-flight jobs finish for up to drainTimeoutMs, then abort
   * the stragglers and hand their jobs back to the queue immediately instead of waiting for leases
   * to expire.
   */
  async stop(): Promise<void> {
    this.stopping = true;
    this.wake?.();
    await this.loopDone;

    const settled = () => Promise.allSettled([...this.inflight.values()].map((e) => e.promise));
    const timedOut = Symbol('timeout');
    if ((await Promise.race([settled(), this.delay(this.opts.drainTimeoutMs, timedOut)])) !== timedOut) {
      this.logger.info('worker drained cleanly');
      return;
    }

    this.logger.warn({ inflight: this.inflight.size }, 'drain timeout reached, aborting in-flight jobs');
    for (const e of this.inflight.values()) {
      e.reason ??= 'shutdown';
      e.abort.abort();
    }
    await Promise.race([settled(), this.delay(this.opts.abortGraceMs ?? 5_000, timedOut)]);
    // Handlers that ignored the abort signal: free their jobs anyway. release() is fence-guarded,
    // so it is a no-op for any job that has already finished.
    for (const e of this.inflight.values()) {
      await release(this.pool, e.job.id, e.job.fence).catch((err) =>
        this.logger.error({ err, jobId: e.job.id }, 'failed to release job on shutdown'),
      );
    }
  }

  private async loop(): Promise<void> {
    while (!this.stopping) {
      const free = this.opts.concurrency - this.inflight.size;
      let claimed = 0;
      if (free > 0) {
        try {
          const t0 = performance.now();
          const jobs = await claim(this.pool, {
            workerId: this.opts.workerId,
            queues: this.opts.queues,
            leaseSeconds: this.opts.leaseSeconds,
            limit: free,
          });
          this.opts.metrics?.claimed((performance.now() - t0) / 1000);
          claimed = jobs.length;
          for (const job of jobs) this.launch(job);
        } catch (err) {
          this.logger.error({ err }, 'claim failed');
          await this.sleepOrWake(1_000);
          continue;
        }
      }
      // A full batch means more work is probably waiting: only pause if we are at capacity.
      if (claimed === 0 || claimed < free || free === 0) {
        await this.sleepOrWake(this.opts.pollIntervalMs * (0.8 + Math.random() * 0.4));
      }
    }
  }

  private launch(job: Job): void {
    const exec: Execution = { job, abort: new AbortController(), reason: null, promise: Promise.resolve() };
    exec.promise = this.execute(exec)
      .catch((err) => this.logger.error({ err, jobId: job.id }, 'unexpected error executing job'))
      .finally(() => {
        this.inflight.delete(job.id);
        this.wake?.(); // a slot just freed up: claim again now rather than at the next poll
      });
    this.inflight.set(job.id, exec);
  }

  private async execute(exec: Execution): Promise<void> {
    const { job } = exec;
    const log = this.logger.child({ jobId: job.id, type: job.type, attempt: job.attempts, fence: job.fence });
    const def = this.registry.get(job.type);
    const started = performance.now();
    // Only registered types become metric labels; arbitrary job types would blow up cardinality.
    const finish = (outcome: JobOutcome) =>
      this.opts.metrics?.jobFinished(def ? job.type : 'unknown', outcome, (performance.now() - started) / 1000);
    if (!def) {
      // Retryable on purpose: during a rolling deploy another version may know this type.
      log.error('no handler registered for job type');
      finish(failLabel(await this.safeFail(job, `no handler registered for job type "${job.type}"`, true, log)));
      return;
    }

    const stop = (reason: AbortReason) => {
      if (exec.reason) return;
      exec.reason = reason;
      exec.abort.abort();
    };

    // Keep the lease alive. If the heartbeat is rejected someone else owns the job now: abort.
    let beating = false;
    const hb = setInterval(() => {
      if (beating) return;
      beating = true;
      heartbeat(this.pool, job.id, job.fence, this.opts.leaseSeconds)
        .then((ok) => {
          if (!ok) {
            log.warn('lease lost, aborting handler');
            stop('lease_lost');
          }
        })
        .catch((err) => log.warn({ err }, 'heartbeat failed (will retry)'))
        .finally(() => {
          beating = false;
        });
    }, this.opts.heartbeatSeconds * 1000);

    const timeoutMs = def.timeoutMs ?? this.opts.defaultHandlerTimeoutMs ?? DEFAULT_HANDLER_TIMEOUT_MS;
    const timer = setTimeout(() => stop('timeout'), timeoutMs);

    try {
      const result = await def.handle(job.payload, {
        jobId: job.id,
        attempt: job.attempts,
        signal: exec.abort.signal,
        logger: log,
      });
      // A handler that ignores the signal may still return after being told to stop. Its result
      // is not trustworthy (lease lost) or not wanted (timeout), so treat the abort as the outcome.
      if (exec.reason) throw new AbortedError(exec.reason, timeoutMs);
      const ok = await this.retryDb(() => complete(this.pool, job.id, job.fence, result), log);
      if (ok) {
        log.info('job succeeded');
        finish('succeeded');
      } else {
        log.warn('ack rejected: job was reassigned (stale fence)');
        finish('stale');
      }
    } catch (err) {
      if (exec.reason === 'lease_lost') {
        log.warn('abandoning job: lease lost');
        finish('lease_lost');
      } else if (exec.reason === 'shutdown') {
        const released = await release(this.pool, job.id, job.fence).catch(() => false);
        log.info({ released }, 'job released on shutdown');
        finish('released');
      } else {
        const retryable = !(err instanceof NonRetryableError);
        // If we aborted the handler for a timeout, report that rather than the handler's own
        // "aborted" rejection, which says nothing about why.
        const message = exec.reason === 'timeout' ? errorMessage(new AbortedError('timeout', timeoutMs)) : errorMessage(err);
        finish(failLabel(await this.safeFail(job, message, retryable, log)));
      }
    } finally {
      clearInterval(hb);
      clearTimeout(timer);
    }
  }

  private async safeFail(job: Job, message: string, retryable: boolean, log: Logger): Promise<FailOutcome | null> {
    try {
      const res = await this.retryDb(
        () => fail(this.pool, job.id, job.fence, message, { retryable, backoff: this.opts.backoff }),
        log,
      );
      log.warn({ outcome: res.outcome, error: message }, 'job failed');
      return res;
    } catch (err) {
      // The lease will expire and the reaper will recover the job.
      log.error({ err }, 'could not record job failure');
      return null;
    }
  }

  /** Acks are idempotent and fence-guarded, so retrying them across a transient DB error is safe. */
  private async retryDb<T>(fn: () => Promise<T>, log: Logger, attempts = 3): Promise<T> {
    for (let i = 1; ; i++) {
      try {
        return await fn();
      } catch (err) {
        if (i >= attempts) throw err;
        log.warn({ err, try: i }, 'database call failed, retrying');
        await this.delay(200 * i, undefined);
      }
    }
  }

  private sleepOrWake(ms: number): Promise<void> {
    return new Promise<void>((resolve) => {
      const t = setTimeout(done, ms);
      function done() {
        clearTimeout(t);
        resolve();
      }
      this.wake = () => {
        this.wake = null;
        done();
      };
    });
  }

  private delay<T>(ms: number, value: T): Promise<T> {
    return new Promise((resolve) => setTimeout(() => resolve(value), ms).unref());
  }
}

function failLabel(res: FailOutcome | null): JobOutcome {
  if (res === null) return 'error';
  return res.outcome === 'retry' ? 'retried' : res.outcome;
}

class AbortedError extends Error {
  constructor(reason: AbortReason, timeoutMs: number) {
    super(reason === 'timeout' ? `handler timed out after ${timeoutMs}ms` : `handler aborted (${reason})`);
    this.name = 'AbortedError';
  }
}
