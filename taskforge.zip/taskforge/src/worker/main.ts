import { randomBytes } from 'node:crypto';
import os from 'node:os';
import { reapExpiredLeases } from '../core/reaper.js';
import { runLoop } from '../core/loop.js';
import { loadConfig } from '../config.js';
import { createPool } from '../db/pool.js';
import { createLogger } from '../logger.js';
import { createMetrics, startMetricsServer, workerMetrics } from '../metrics.js';
import { createDefaultRegistry } from './handlers.js';
import { Worker } from './worker.js';

const cfg = loadConfig();
const workerId = `${os.hostname()}-${process.pid}-${randomBytes(3).toString('hex')}`;
const logger = createLogger(cfg.LOG_LEVEL, { role: 'worker', workerId });
const pool = createPool(cfg.DATABASE_URL, cfg.DB_POOL_MAX);
const metrics = createMetrics();
const metricsServer = startMetricsServer(metrics.registry, cfg.METRICS_PORT, logger);

const registry = createDefaultRegistry({ allowPrivateWebhooks: cfg.ALLOW_PRIVATE_WEBHOOKS });
logger.info({ handlers: registry.types() }, 'registered handlers');

const worker = new Worker(
  pool,
  registry,
  {
    workerId,
    queues: cfg.WORKER_QUEUES,
    concurrency: cfg.WORKER_CONCURRENCY,
    leaseSeconds: cfg.LEASE_SECONDS,
    heartbeatSeconds: cfg.HEARTBEAT_SECONDS,
    pollIntervalMs: cfg.POLL_INTERVAL_MS,
    drainTimeoutMs: cfg.DRAIN_TIMEOUT_SECONDS * 1000,
    metrics: workerMetrics(metrics),
  },
  logger,
);
metrics.inflightSource.read = () => worker.inflightCount;

// Every worker runs a reaper. They are safe to run concurrently (FOR UPDATE SKIP LOCKED), and it
// means crash recovery needs no separate singleton process.
const reaper = runLoop(
  'reaper',
  cfg.REAPER_INTERVAL_SECONDS * 1000,
  async () => {
    const r = await reapExpiredLeases(pool);
    if (r.requeued) metrics.reaped.inc({ result: 'requeued' }, r.requeued);
    if (r.dead) metrics.reaped.inc({ result: 'dead' }, r.dead);
    if (r.requeued || r.dead) logger.warn(r, 'recovered jobs with expired leases');
  },
  logger,
);

worker.start();

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'shutting down');
  // Hard stop in case something hangs (must stay below the pod's terminationGracePeriodSeconds).
  setTimeout(() => process.exit(1), (cfg.DRAIN_TIMEOUT_SECONDS + 10) * 1000).unref();
  await reaper.stop();
  await worker.stop();
  metricsServer.close();
  await pool.end();
  logger.info('shutdown complete');
  process.exit(0);
}
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('unhandledRejection', (err) => {
  logger.fatal({ err }, 'unhandled rejection');
  process.exit(1);
});
