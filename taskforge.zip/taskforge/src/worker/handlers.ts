import { z } from 'zod';
import { HandlerRegistry, NonRetryableError } from './registry.js';
import { createWebhookHandler } from './webhook.js';

const abortableSleep = (ms: number, signal: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new Error('aborted'));
      },
      { once: true },
    );
  });

/** Built-in handlers: a real one (webhook delivery) and a few for demos and load tests. */
export function createDefaultRegistry(opts: { allowPrivateWebhooks?: boolean } = {}): HandlerRegistry {
  return new HandlerRegistry()
    .register('http.webhook', createWebhookHandler({ allowPrivate: opts.allowPrivateWebhooks }))
    .register('demo.echo', async (payload, ctx) => {
      ctx.logger.info({ payload }, 'echo');
      return { echoed: payload };
    })
    .register('demo.sleep', async (payload, ctx) => {
      const { ms } = z.object({ ms: z.number().int().min(0).max(60_000) }).parse(payload ?? {});
      await abortableSleep(ms, ctx.signal);
      return { sleptMs: ms };
    })
    // Fails until the given attempt number, then succeeds: shows retries and backoff in action.
    .register('demo.flaky', async (payload, ctx) => {
      const parsed = z.object({ succeedOnAttempt: z.number().int().min(1) }).safeParse(payload);
      if (!parsed.success) throw new NonRetryableError('payload needs { succeedOnAttempt: number }');
      if (ctx.attempt < parsed.data.succeedOnAttempt) {
        throw new Error(`simulated failure on attempt ${ctx.attempt}`);
      }
      return { succeededOnAttempt: ctx.attempt };
    });
}
