import dns from 'node:dns';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import { z } from 'zod';
import { NonRetryableError } from './registry.js';
import type { HandlerDef } from './registry.js';

const payloadSchema = z.object({
  url: z.string().url(),
  method: z.enum(['POST', 'PUT', 'PATCH']).default('POST'),
  headers: z.record(z.string(), z.string()).optional(),
  body: z.unknown().optional(),
});

// Ranges a user-supplied URL must never reach: loopback, private networks, link-local (which
// includes the 169.254.169.254 cloud metadata service), CGNAT, multicast and reserved space.
const blocked = new net.BlockList();
for (const [net4, prefix] of [
  ['0.0.0.0', 8],
  ['10.0.0.0', 8],
  ['100.64.0.0', 10],
  ['127.0.0.0', 8],
  ['169.254.0.0', 16],
  ['172.16.0.0', 12],
  ['192.0.0.0', 24],
  ['192.168.0.0', 16],
  ['198.18.0.0', 15],
  ['224.0.0.0', 4],
  ['240.0.0.0', 4],
] as const) {
  blocked.addSubnet(net4, prefix, 'ipv4');
}
for (const [net6, prefix] of [
  ['::', 128],
  ['::1', 128],
  ['fc00::', 7],
  ['fe80::', 10],
  ['ff00::', 8],
] as const) {
  blocked.addSubnet(net6, prefix, 'ipv6');
}

export function isBlockedAddress(address: string): boolean {
  const family = net.isIP(address);
  if (family === 0) return true; // not an IP literal: fail closed
  return blocked.check(address, family === 6 ? 'ipv6' : 'ipv4');
}

class BlockedAddressError extends NonRetryableError {
  override name = 'BlockedAddressError';
}

/**
 * DNS lookup that refuses private addresses. Validating inside the connection's own lookup (rather
 * than resolving first and connecting later) closes the DNS-rebinding window: the address that is
 * checked is the address that is dialled.
 */
const safeLookup: net.LookupFunction = (hostname, options, callback) => {
  dns.lookup(hostname, { all: true, family: options.family, hints: options.hints }, (err, addresses) => {
    if (err) return (callback as (e: Error | null) => void)(err);
    const bad = addresses.find((a) => isBlockedAddress(a.address));
    if (bad) {
      return (callback as (e: Error | null) => void)(
        new BlockedAddressError(`refusing to connect to private address ${bad.address} (${hostname})`),
      );
    }
    if (options.all) return (callback as (e: null, a: dns.LookupAddress[]) => void)(null, addresses);
    const first = addresses[0]!;
    return callback(null, first.address, first.family);
  });
};

export interface WebhookOptions {
  /** Disable the SSRF guard. For local development and tests only. */
  allowPrivate?: boolean;
  timeoutMs?: number;
}

/**
 * Delivers an HTTP request. Retry policy follows the status code:
 *   2xx            success
 *   408, 429, 5xx  retry with backoff (transient)
 *   other 4xx, 3xx never retry (we do not follow redirects: they are an SSRF vector)
 * The job id is sent as Idempotency-Key so receivers can deduplicate at-least-once deliveries.
 */
export function createWebhookHandler(options: WebhookOptions = {}): HandlerDef {
  return {
    timeoutMs: options.timeoutMs ?? 30_000,
    async handle(rawPayload, ctx) {
      const parsed = payloadSchema.safeParse(rawPayload);
      if (!parsed.success) {
        throw new NonRetryableError(`invalid webhook payload: ${parsed.error.issues.map((i) => i.message).join('; ')}`);
      }
      const { url, method, headers, body } = parsed.data;
      const target = new URL(url);
      if (target.protocol !== 'http:' && target.protocol !== 'https:') {
        throw new NonRetryableError(`unsupported protocol ${target.protocol}`);
      }
      const host = target.hostname.replace(/^\[|\]$/g, '');
      if (!options.allowPrivate && net.isIP(host) !== 0 && isBlockedAddress(host)) {
        throw new BlockedAddressError(`refusing to connect to private address ${host}`);
      }

      const data = body === undefined ? undefined : JSON.stringify(body);
      const status = await new Promise<number>((resolve, reject) => {
        const lib = target.protocol === 'https:' ? https : http;
        const req = lib.request(
          target,
          {
            method,
            signal: ctx.signal,
            ...(options.allowPrivate ? {} : { lookup: safeLookup }),
            headers: {
              'content-type': 'application/json',
              'user-agent': 'taskforge/0.1',
              'idempotency-key': ctx.jobId,
              'x-taskforge-job-id': ctx.jobId,
              'x-taskforge-attempt': String(ctx.attempt),
              ...(data === undefined ? {} : { 'content-length': Buffer.byteLength(data) }),
              ...headers,
            },
          },
          (res) => {
            res.resume(); // we only need the status; discard the body
            res.on('end', () => resolve(res.statusCode ?? 0));
            res.on('error', reject);
          },
        );
        req.on('error', reject);
        req.end(data);
      });

      if (status >= 200 && status < 300) return { status };
      if (status === 408 || status === 429 || status >= 500) throw new Error(`webhook responded ${status}`);
      throw new NonRetryableError(`webhook responded ${status}`);
    },
  };
}
