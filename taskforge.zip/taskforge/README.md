# TaskForge

Distributed job scheduler on PostgreSQL (Node.js + TypeScript).

- Cron, delayed and priority jobs
- Exponential-backoff retries with jitter, dead-letter queue, idempotency keys
- `FOR UPDATE SKIP LOCKED` claiming, lease/heartbeat crash recovery, fencing tokens
- Authenticated REST API, Prometheus metrics, Kubernetes/Helm deployment

Status: under construction. See `docs/` for design notes as they are added.

## Layout

```
src/
  db/        connection pool, migration runner
  core/      enqueue, claim, ack/fail, reaper (the scheduler engine)
  api/       Fastify REST service
  worker/    worker process and job handlers
  scheduler/ cron expansion with leader election
migrations/  versioned SQL
tests/       unit + integration tests
scripts/     benchmarks and tooling
docs/        architecture and trade-offs
```
