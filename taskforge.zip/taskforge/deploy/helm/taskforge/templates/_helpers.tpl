{{/* Names and labels */}}
{{- define "taskforge.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "taskforge.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "taskforge.selectorLabels" -}}
app.kubernetes.io/name: {{ include "taskforge.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "taskforge.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "taskforge.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "taskforge.image" -}}
{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{- define "taskforge.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ include "taskforge.fullname" . }}{{- else }}default{{- end }}
{{- end }}

{{/* Which Secret holds DATABASE_URL, and which holds the optional ADMIN_API_KEY */}}
{{- define "taskforge.databaseSecretName" -}}
{{- if .Values.secrets.existingSecret }}{{ .Values.secrets.existingSecret }}
{{- else if .Values.postgres.enabled }}{{ include "taskforge.fullname" . }}-postgres
{{- else }}{{ include "taskforge.fullname" . }}
{{- end }}
{{- end }}

{{- define "taskforge.appSecretName" -}}
{{- if .Values.secrets.existingSecret }}{{ .Values.secrets.existingSecret }}{{- else }}{{ include "taskforge.fullname" . }}{{- end }}
{{- end }}

{{/* Fail at render time on settings that would break the app's own shutdown or lease timing. */}}
{{- define "taskforge.validate" -}}
{{- if lt (int .Values.worker.terminationGracePeriodSeconds) (add (int .Values.config.drainTimeoutSeconds) 10) }}
{{- fail (printf "worker.terminationGracePeriodSeconds (%d) must be at least config.drainTimeoutSeconds + 10 (%d): otherwise Kubernetes SIGKILLs workers before they finish draining" (int .Values.worker.terminationGracePeriodSeconds) (add (int .Values.config.drainTimeoutSeconds) 10)) }}
{{- end }}
{{- if lt (int .Values.api.terminationGracePeriodSeconds) (add (int .Values.config.shutdownDelaySeconds) 20) }}
{{- fail (printf "api.terminationGracePeriodSeconds (%d) must be at least config.shutdownDelaySeconds + 20 (%d)" (int .Values.api.terminationGracePeriodSeconds) (add (int .Values.config.shutdownDelaySeconds) 20)) }}
{{- end }}
{{- if ge (mul 2 (int .Values.config.heartbeatSeconds)) (int .Values.config.leaseSeconds) }}
{{- fail "config.heartbeatSeconds must be less than half of config.leaseSeconds, or healthy workers can lose their leases" }}
{{- end }}
{{- if and .Values.postgres.enabled .Values.migrations.job.enabled }}
{{- fail "migrations.job.enabled cannot be combined with postgres.enabled: the pre-install hook runs before the bundled database exists. Set migrations.job.enabled=false and migrations.runOnApiStartup=true" }}
{{- end }}
{{- if and .Values.migrations.job.enabled (not .Values.secrets.existingSecret) }}
{{- fail "migrations.job.enabled requires secrets.existingSecret: the hook runs before the chart's own Secret is created" }}
{{- end }}
{{- if and (not .Values.postgres.enabled) (not .Values.secrets.existingSecret) (not .Values.secrets.databaseUrl) }}
{{- fail "no database configured: set postgres.enabled=true (demo), secrets.existingSecret, or secrets.databaseUrl" }}
{{- end }}
{{- end }}

{{/* Pod-level hardening shared by every workload */}}
{{- define "taskforge.podSecurityContext" -}}
runAsNonRoot: true
runAsUser: 1000
runAsGroup: 1000
fsGroup: 1000
seccompProfile:
  type: RuntimeDefault
{{- end }}

{{- define "taskforge.containerSecurityContext" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop: ["ALL"]
{{- end }}

{{/* Environment shared by api, worker and scheduler */}}
{{- define "taskforge.commonEnv" -}}
- name: DATABASE_URL
  valueFrom:
    secretKeyRef:
      name: {{ include "taskforge.databaseSecretName" . }}
      key: DATABASE_URL
- name: METRICS_PORT
  value: {{ .Values.metrics.port | quote }}
{{- with .Values.extraEnv }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Soft anti-affinity: spread replicas of one component across nodes */}}
{{- define "taskforge.scheduling" -}}
{{- $root := .root -}}
{{- with $root.Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $root.Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $root.Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if $root.Values.topologySpread }}
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        {{- include "taskforge.selectorLabels" $root | nindent 8 }}
        app.kubernetes.io/component: {{ .component }}
{{- end }}
{{- end }}
