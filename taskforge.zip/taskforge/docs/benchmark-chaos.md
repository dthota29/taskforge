# TaskForge benchmark results (chaos)

Result: **PASS**. Generated 2026-10-22T14:54:16.249Z by `npm run bench:chaos`.

## Setup
- 20,000 jobs, 16 worker processes x 10 concurrent handlers (160 in flight), one PostgreSQL 16.15
- Host: 18 logical CPUs (Intel(R) Core(TM) Ultra 5 135H), 31 GiB RAM, win32, Node v25.6.1. Database in Docker, same host, so results are a lower bound on a dedicated database.
- Workload: handler does one INSERT per job (a realistic minimum: real handlers do I/O). Lease 5s.
- Every job is enqueued first, then all workers are released at once against the full backlog: the maximum-contention case for `FOR UPDATE SKIP LOCKED`.
- Chaos: bench-00, bench-01, bench-02 were SIGKILLed at 17.8s with jobs in flight.

## Throughput and latency
| Metric | Value |
|---|---|
| Enqueue (API path, 32 submitters) | 474 jobs/s |
| Drain wall time | 67.1 s |
| Processing throughput | **298 jobs/s** |
| Claim to finish, p50 / p95 / p99 | 217 / 462.6 / 755.4 ms |
| Jobs per worker (min / avg / max) | 392 / 1,251 / 1469 across 16 workers |

## Correctness checks
| Check | Expected | Actual | |
|---|---|---|---|
| claim query uses jobs_claim_idx | true | true | ok |
| jobs submitted | 20000 | 20000 | ok |
| jobs succeeded | 20000 | 20000 | ok |
| every job executed at least once | 20000 | 20000 | ok |
| jobs completed by exactly one attempt | 0 | 0 | ok |
| fencing tokens contiguous per job (1..k) | 0 | 0 | ok |
| no claim left open | 0 | 0 | ok |
| attempt rows that succeeded | 20000 | 20000 | ok |
| crashed-worker claims recovered by the reaper | true | true | ok |

Crash recovery: 21 claims held by dead workers were reclaimed after lease expiry, and 10 jobs ran again (at-least-once delivery). Each job was still completed by exactly one attempt.

## Claim query plan on the loaded table
```
Limit (actual time=0.192..0.232 rows=10 loops=1)
  Buffers: shared hit=25
  ->  LockRows (actual time=0.189..0.225 rows=10 loops=1)
        Buffers: shared hit=25
        ->  Index Scan using jobs_claim_idx on jobs (actual time=0.108..0.127 rows=10 loops=1)
              Index Cond: ((queue = 'default'::text) AND (run_at <= now()))
              Filter: (status = 'queued'::text)
              Buffers: shared hit=5
Planning:
  Buffers: shared hit=101
Planning Time: 14.244 ms
Execution Time: 0.417 ms
```
