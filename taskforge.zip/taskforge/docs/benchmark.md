# TaskForge benchmark results

Result: **PASS**. Generated 2026-10-22T14:51:15.930Z by `npm run bench`.

## Setup
- 20,000 jobs, 16 worker processes x 10 concurrent handlers (160 in flight), one PostgreSQL 16.15
- Host: 18 logical CPUs (Intel(R) Core(TM) Ultra 5 135H), 31 GiB RAM, win32, Node v25.6.1. Database in Docker, same host, so results are a lower bound on a dedicated database.
- Workload: handler does one INSERT per job (a realistic minimum: real handlers do I/O). Lease 30s.
- Every job is enqueued first, then all workers are released at once against the full backlog: the maximum-contention case for `FOR UPDATE SKIP LOCKED`.

## Throughput and latency
| Metric | Value |
|---|---|
| Enqueue (API path, 32 submitters) | 565 jobs/s |
| Drain wall time | 59.2 s |
| Processing throughput | **338 jobs/s** |
| Claim to finish, p50 / p95 / p99 | 230 / 411.2 / 586.2 ms |
| Jobs per worker (min / avg / max) | 1225 / 1,250 / 1261 across 16 workers |

## Correctness checks
| Check | Expected | Actual | |
|---|---|---|---|
| claim query uses jobs_claim_idx | true | true | ok |
| jobs submitted | 20000 | 20000 | ok |
| jobs succeeded | 20000 | 20000 | ok |
| every job executed at least once | 20000 | 20000 | ok |
| jobs completed by exactly one attempt | 0 | 0 | ok |
| fencing tokens contiguous per job (1..k) | 0 | 0 | ok |
| no claim left open | 0 | 0 | ok |
| attempt rows that succeeded | 20000 | 20000 | ok |
| DUPLICATE CLAIMS (job claimed more than once) | 0 | 0 | ok |
| total handler executions | 20000 | 20000 | ok |
| no lease expired in a healthy run | 0 | 0 | ok |

## Claim query plan on the loaded table
```
Limit (actual time=0.137..0.182 rows=10 loops=1)
  Buffers: shared hit=17
  ->  LockRows (actual time=0.134..0.176 rows=10 loops=1)
        Buffers: shared hit=17
        ->  Index Scan using jobs_claim_idx on jobs (actual time=0.107..0.134 rows=10 loops=1)
              Index Cond: ((queue = 'default'::text) AND (run_at <= now()))
              Filter: (status = 'queued'::text)
              Buffers: shared hit=7
Planning:
  Buffers: shared hit=130 read=5
Planning Time: 13.201 ms
Execution Time: 0.333 ms
```
